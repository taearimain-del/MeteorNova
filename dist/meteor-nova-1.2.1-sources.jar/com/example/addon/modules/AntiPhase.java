package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3489;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AntiPhase extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgItems = settings.createGroup("Items");

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("range")
            .description("Range to detect enemies.")
            .defaultValue(4.5).min(0.0).max(5.0).sliderRange(0.0, 5.0)
            .build());

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("Delay between placements in milliseconds. Each placement costs several packets.")
            .defaultValue(100).min(0).max(1000).sliderMax(1000)
            .build());

    private final Setting<Integer> bpt = sgGeneral.add(new IntSetting.Builder()
            .name("blocks-per-tick")
            .description("How many blocks to place per tick.")
            .defaultValue(2).min(1).max(10).sliderRange(1, 10)
            .build());

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Rotate toward the block being placed.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> raytrace = sgGeneral.add(new BoolSetting.Builder()
            .name("raytrace")
            .description("Only target enemies you have line of sight to.")
            .defaultValue(false)
            .build());

    private final Setting<Boolean> onlyInHole = sgGeneral.add(new BoolSetting.Builder()
            .name("only-in-hole")
            .description("Only place when the enemy is surrounded on all four sides.")
            .defaultValue(false)
            .build());

    private final Setting<Boolean> swapBack = sgGeneral.add(new BoolSetting.Builder()
            .name("swap-back")
            .description("Return to your original hotbar slot after placing.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> buttons = sgItems.add(new BoolSetting.Builder()
            .name("buttons")
            .description("Use any button.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> scaffolding = sgItems.add(new BoolSetting.Builder()
            .name("scaffolding")
            .description("Use scaffolding.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> webs = sgItems.add(new BoolSetting.Builder()
            .name("webs")
            .description("Use cobwebs.")
            .defaultValue(false)
            .build());

    private long lastPlaceAt = 0L;

    public AntiPhase() {
        super(Addon.CATEGORY, "anti-phase", "Blocks enemies from phasing by filling their feet.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("AntiPhase", true);
        lastPlaceAt = 0L;
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("AntiPhase", false);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        long now = System.currentTimeMillis();
        if (now - lastPlaceAt < delay.get())
            return;

        FindItemResult item = InvUtils.findInHotbar(this::isPlaceable);
        if (!item.found())
            return;

        List<class_1657> targets = new ArrayList<>();
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724 || !player.method_5805() || player.method_7325())
                continue;
            if (Friends.get().isFriend(player))
                continue;
            if (mc.field_1724.method_5739(player) > range.get())
                continue;
            if (raytrace.get() && !mc.field_1724.method_6057(player))
                continue;
            targets.add(player);
        }

        targets.sort(Comparator.comparingDouble(mc.field_1724::method_5739));

        int placed = 0;
        for (class_1657 player : targets) {
            if (placed >= bpt.get())
                break;

            class_2338 pos = player.method_24515();

            if (onlyInHole.get() && !isSurrounded(pos))
                continue;
            // Only that the block is replaceable: BlockUtils.canPlace asks
            // whether obsidian would fit, which an enemy standing in the way
            // always denies, and place() rechecks with the real block anyway.
            if (!mc.field_1687.method_8320(pos).method_45474())
                continue;

            // No entity check: the whole point is to place where an enemy
            // stands, and only collision-less blocks can go there at all.
            if (BlockUtils.place(pos, item, rotate.get(), 50, true, false, swapBack.get())) {
                placed++;
                lastPlaceAt = now;
            }
        }
    }

    private boolean isPlaceable(class_1799 stack) {
        if (stack.method_7960())
            return false;
        if (buttons.get() && stack.method_31573(class_3489.field_15551))
            return true;
        if (scaffolding.get() && stack.method_31574(class_1802.field_16482))
            return true;
        return webs.get() && stack.method_31574(class_1802.field_8786);
    }

    /** True when all four horizontal neighbours are blast-resistant surround blocks. */
    private boolean isSurrounded(class_2338 pos) {
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2248 block = mc.field_1687.method_8320(pos.method_10093(dir)).method_26204();
            if (block != class_2246.field_10540 && block != class_2246.field_9987 && block != class_2246.field_10443)
                return false;
        }
        return true;
    }
}
