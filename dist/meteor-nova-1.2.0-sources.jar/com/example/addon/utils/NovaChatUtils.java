package com.example.addon.utils;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public class NovaChatUtils {
    private static final class_310 mc = class_310.method_1551();

    public static void sendToggleMsg(String moduleName, boolean on) {
        if (mc.field_1705 == null || mc.field_1705.method_1743() == null)
            return;

        class_5250 text = class_2561.method_43470("[Nova] ").method_27692(class_124.field_1076);
        if (on) {
            text.method_10852(class_2561.method_43470("[+] ").method_27692(class_124.field_1060));
        } else {
            text.method_10852(class_2561.method_43470("[-] ").method_27692(class_124.field_1061));
        }
        text.method_10852(class_2561.method_43470(moduleName).method_27692(class_124.field_1068));

        mc.field_1705.method_1743().method_1812(text);
    }

    public static void sendInfoMsg(String moduleName, String message) {
        if (mc.field_1705 == null || mc.field_1705.method_1743() == null)
            return;

        class_5250 text = class_2561.method_43470("[Nova] ").method_27692(class_124.field_1076);
        text.method_10852(class_2561.method_43470(moduleName + " ").method_27692(class_124.field_1068));
        text.method_10852(class_2561.method_43470(message));

        mc.field_1705.method_1743().method_1812(text);
    }
}
