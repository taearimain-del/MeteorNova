package com.example.addon.utils;

import meteordevelopment.meteorclient.utils.misc.Keybind;
import net.minecraft.class_11908;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

/**
 * Feeds synthetic key events to Minecraft's Keyboard so that everything
 * listening to it reacts: Meteor's own KeyboardMixin, and just as importantly
 * mods outside Meteor's module list, such as the external client whose Web
 * Aura ConcreteWeb drives.
 *
 * Keyboard#onKey is private and takes a KeyInput as of 1.21.11 - the addon's
 * access widener opens it back up, and the argument order it wants is
 * (window, action, input).
 */
public class NovaKeybindUtils {
    /** Sends a press/release pair for the bound key, once per press. */
    public static void pressKey(Keybind keybind, int presses) {
        if (keybind == null || !keybind.isSet() || !keybind.isKey())
            return;

        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1774 == null || mc.method_22683() == null)
            return;

        long window = mc.method_22683().method_4490();
        class_11908 input = new class_11908(keybind.getValue(), 0, 0);

        for (int i = 0; i < presses; i++) {
            mc.field_1774.method_1466(window, GLFW.GLFW_PRESS, input);
            mc.field_1774.method_1466(window, GLFW.GLFW_RELEASE, input);
        }
    }
}
