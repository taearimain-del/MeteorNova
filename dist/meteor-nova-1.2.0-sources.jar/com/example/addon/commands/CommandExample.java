package com.example.addon.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class CommandExample extends Command {
    public CommandExample() {
        super("example", "Sends a message to chat.");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            info("Example command executed!");
            return SINGLE_SUCCESS;
        });
    }
}
