package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1540;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2292;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_8810;
import java.util.function.Predicate;

public class ConcreteDefense extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("mode")
            .description("When to place the obstruction.")
            .defaultValue(Mode.Strict)
            .build());

    private final Setting<BlockType> blockType = sgGeneral.add(new EnumSetting.Builder<BlockType>()
            .name("block-type")
            .description("Which block to place.")
            .defaultValue(BlockType.Button)
            .build());

    private final Setting<Integer> range = sgGeneral.add(new IntSetting.Builder()
            .name("smart-range")
            .description("Enemy range to trigger placing.")
            .defaultValue(3)
            .min(1)
            .sliderRange(1, 7)
            .build());

    private final Setting<Boolean> silentSwap = sgGeneral.add(new BoolSetting.Builder()
            .name("silent-inventory-swap")
            .description("Temporarily moves the item to hotbar slot.")
            .defaultValue(true)
            .build());

    private final Setting<Integer> hotbarSlotSetting = sgGeneral.add(new IntSetting.Builder()
            .name("hotbar-slot")
            .description("Which hotbar slot (0-8) to use for swapping.")
            .defaultValue(0)
            .min(0)
            .max(8)
            .sliderMax(8)
            .build());

    private final Setting<Integer> returnDelay = sgGeneral.add(new IntSetting.Builder()
            .name("return-delay")
            .description("Delay before returning item to inventory (in ticks).")
            .defaultValue(40)
            .min(1)
            .sliderMax(200)
            .build());

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Rotate toward blocks when placing.")
            .defaultValue(true)
            .build());

    private int returnTimer = -1;
    private int originalSlot = -1;
    private boolean waitingToReturn = false;
    private int cooldown = 0;

    public ConcreteDefense() {
        super(Addon.CATEGORY, "concrete-defense",
                "Places a button or web under yourself to break falling concrete.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("ConcreteDefense", true);
        returnTimer = -1;
        originalSlot = -1;
        waitingToReturn = false;
        cooldown = 0;
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("ConcreteDefense", false);
        if (waitingToReturn && originalSlot != -1) {
            int hotbarSlot = hotbarSlotSetting.get();
            InvUtils.move().from(hotbarSlot).to(originalSlot);
        }
    }

    @EventHandler
    public void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        if (waitingToReturn) {
            if (--returnTimer <= 0) {
                int hotbarSlot = hotbarSlotSetting.get();
                InvUtils.move().from(hotbarSlot).to(originalSlot);
                waitingToReturn = false;
            }
        }

        if (cooldown > 0)
            cooldown--;

        if (TargetUtils.getPlayerTarget(range.get(), SortPriority.LowestDistance) != null) {
            if (mode.get() == Mode.Smart) {
                if (isConcreteAbove())
                    tryPlace();
            } else {
                tryPlace();
            }
        }
    }

    private void tryPlace() {
        class_2338 currentPos = mc.field_1724.method_24515();
        // Check if already protected
        class_2248 currentBlock = mc.field_1687.method_8320(currentPos).method_26204();
        if (isProtectionBlock(currentBlock))
            return;

        // Determine what item to look for
        Predicate<class_1799> itemPredicate = getItemPredicate();

        FindItemResult itemResult = InvUtils.findInHotbar(itemPredicate);

        originalSlot = -1;
        boolean swapped = false;

        if (!itemResult.found() && silentSwap.get()) {
            FindItemResult invItem = InvUtils.find(itemPredicate);
            if (invItem.found() && invItem.slot() >= 9) {
                int hotbarSlot = hotbarSlotSetting.get();
                originalSlot = invItem.slot();

                InvUtils.move().from(invItem.slot()).to(hotbarSlot);
                swapped = true;

                itemResult = InvUtils.findInHotbar(itemPredicate);
            }
        }

        if (!itemResult.found()) {
            if (cooldown == 0) {
                warning("No required item (Button/Web) in hotbar or inventory.");
                cooldown = 40; // 2 seconds
            }
            return;
        }

        if (rotate.get()) {
            Rotations.rotate(Rotations.getYaw(currentPos.method_46558()), Rotations.getPitch(currentPos.method_46558()));
        }

        BlockUtils.place(currentPos, itemResult, rotate.get(), 0);

        if (swapped && originalSlot != -1) {
            returnTimer = returnDelay.get();
            waitingToReturn = true;
        }
    }

    private Predicate<class_1799> getItemPredicate() {
        return stack -> {
            class_1792 item = stack.method_7909();
            if (blockType.get() == BlockType.Web) {
                return item == class_1802.field_8786;
            } else {
                return class_2248.method_9503(item) instanceof class_2269;
            }
        };
    }

    private boolean isProtectionBlock(class_2248 block) {
        if (blockType.get() == BlockType.Web) {
            return block == class_2246.field_10343;
        }
        // Button or similar non-collision block that breaks falling blocks
        return block instanceof class_2269 || block instanceof class_8810 || block == class_2246.field_10343;
    }

    private boolean isConcreteAbove() {
        class_2338 base = mc.field_1724.method_24515();

        // Check blocks above (physically placed)
        for (int i = 1; i <= 3; i++) {
            if (mc.field_1687.method_8320(base.method_10086(i)).method_26204() instanceof class_2292)
                return true;
        }

        // Check falling entities
        class_238 box = new class_238(
                mc.field_1724.method_23317() - 0.5, mc.field_1724.method_23318() + 1, mc.field_1724.method_23321() - 0.5,
                mc.field_1724.method_23317() + 0.5, mc.field_1724.method_23318() + 4, mc.field_1724.method_23321() + 0.5);

        for (class_1297 entity : mc.field_1687.method_8335(null, box)) {
            if (entity instanceof class_1540 falling) {
                if (falling.method_6962().method_26204() instanceof class_2292)
                    return true;
            }
        }

        return false;
    }

    public enum Mode {
        Strict,
        Smart
    }

    public enum BlockType {
        Button,
        Web
    }
}
