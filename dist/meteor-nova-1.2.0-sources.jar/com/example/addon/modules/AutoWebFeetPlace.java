package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import com.example.addon.utils.NovaKeybindUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

public class AutoWebFeetPlace extends Module {
    public enum PlaceItem {
        Cobweb, Ladder, Button
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgTarget = settings.createGroup("Targeting");
    private final SettingGroup sgPlace = settings.createGroup("Placement");
    private final SettingGroup sgInv = settings.createGroup("Inventory");

    // General
    private final Setting<PlaceItem> itemMode = sgGeneral.add(new EnumSetting.Builder<PlaceItem>()
            .name("place-item").description("What to place into the broken surround slot.")
            .defaultValue(PlaceItem.Cobweb).build());

    private final Setting<Keybind> resetKey = sgGeneral.add(new KeybindSetting.Builder()
            .name("reset-key").description("Key to toggle SpeedMine (Reset InstaMine).")
            .defaultValue(Keybind.fromKey(GLFW.GLFW_KEY_4)).build());

    // Targeting
    private final Setting<Double> range = sgTarget.add(new DoubleSetting.Builder()
            .name("range").description("Target acquisition range.")
            .defaultValue(6.5).min(1.0).sliderMin(2.0).sliderMax(12.0).build());

    private final Setting<Boolean> ignoreFriends = sgTarget.add(new BoolSetting.Builder()
            .name("ignore-friends").description("Do not target players on your friends list.")
            .defaultValue(true).build());

    private final Setting<Boolean> ignoreNaked = sgTarget.add(new BoolSetting.Builder()
            .name("ignore-naked").description("Ignore players with no armor equipped.")
            .defaultValue(false).build());

    // Placement
    private final Setting<Double> attemptsPerSecond = sgPlace.add(new DoubleSetting.Builder()
            .name("APS").description("Placement attempts per second (spam rate).")
            .defaultValue(6.0).min(0.5).sliderMin(0.5).sliderMax(20.0).build());

    private final Setting<Boolean> rotate = sgPlace.add(new BoolSetting.Builder()
            .name("rotate").description("Rotate to the block being placed.")
            .defaultValue(true).build());

    private final Setting<Boolean> silentSwap = sgPlace.add(new BoolSetting.Builder()
            .name("silent-swap").description("Silently use item from hotbar without changing your selected slot.")
            .defaultValue(true).build());

    private final Setting<Boolean> requireAir = sgPlace.add(new BoolSetting.Builder()
            .name("only-when-air").description("Only attempt when the surround slot is placeable (air/replaceable).")
            .defaultValue(true).build());

    private final Setting<Boolean> preferClosestSide = sgPlace.add(new BoolSetting.Builder()
            .name("prefer-closest-hole").description("If multiple sides broke, prefer the one closest to you.")
            .defaultValue(true).build());

    private final Setting<Boolean> pauseWhileEating = sgPlace.add(new BoolSetting.Builder()
            .name("pause-while-eating")
            .description("Temporarily pauses while you're eating food.")
            .defaultValue(true)
            .build());

    // Inventory
    private final Setting<Boolean> grabFromInventory = sgInv.add(new BoolSetting.Builder()
            .name("grab-from-inventory")
            .description("If not in hotbar, move a stack from main inventory into the chosen hotbar slot.")
            .defaultValue(true).build());

    private final Setting<Integer> grabHotbarSlot = sgInv.add(new IntSetting.Builder()
            .name("hotbar-slot").description("Hotbar slot (0-8) to receive the item when grabbing from inventory.")
            .defaultValue(8).min(0).max(8).sliderMin(0).sliderMax(8).build());

    private final Setting<Boolean> preSwapOnEnable = sgInv.add(new BoolSetting.Builder()
            .name("pre-swap-on-enable").description("On enable, move the needed item to the configured hotbar slot.")
            .defaultValue(true).build());

    private final Setting<Boolean> stashOldHotbar = sgInv.add(new BoolSetting.Builder()
            .name("stash-old-hotbar")
            .description("If the hotbar slot is occupied, stash its stack in the first empty main slot.")
            .defaultValue(true).build());

    private final Setting<Boolean> returnOnDisable = sgInv.add(new BoolSetting.Builder()
            .name("return-on-disable").description("On disable, return items to their original slots if possible.")
            .defaultValue(true).build());

    // Timing
    private long lastAttemptNs = 0;

    // Surround lock state
    private class_2338 lockedFeetPos = null;
    private final Set<class_2338> lockedSurround = new HashSet<>();
    private boolean surroundLocked = false;

    // Pre-swap bookkeeping
    private boolean didPreSwap = false;
    private int preSwapSourceMainSlot = -1;
    private int preSwapHotbarSlot = -1;
    private int stashedHotbarToMainSlot = -1;

    public AutoWebFeetPlace() {
        super(Addon.CATEGORY, "auto-web-feet-place",
                "Places cobweb, ladder, or any button after enemies surround/feet-place is broken.");
    }

    @Override
    public void onActivate() {
        lastAttemptNs = 0;
        clearLock();
        performPreSwapIfNeeded();
    }

    @Override
    public void onDeactivate() {
        if (returnOnDisable.get())
            undoPreSwapIfNeeded();
        clearLock();
    }

    private void clearLock() {
        surroundLocked = false;
        lockedFeetPos = null;
        lockedSurround.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        if (pauseWhileEating.get() && mc.field_1724.method_6115() && isFood(mc.field_1724.method_6030())) {
            return;
        }

        final class_1657 target = findNearestTarget();
        if (target == null) {
            clearLock();
            return;
        }

        double aps = Math.max(0.5, attemptsPerSecond.get());
        long intervalNs = (long) (1_000_000_000L / aps);
        long now = System.nanoTime();
        if (now - lastAttemptNs < intervalNs)
            return;
        lastAttemptNs = now;

        class_2338 feet = target.method_24515();
        if (!feet.equals(lockedFeetPos))
            clearLock();

        if (!surroundLocked) {
            class_2338[] four = surroundPositions(feet);
            if (allSolid(four)) {
                for (class_2338 p : four)
                    lockedSurround.add(p.method_10062());
                lockedFeetPos = feet.method_10062();
                surroundLocked = true;
            } else
                return;
        }

        class_2338 broken = pickBrokenSlot();
        if (broken == null)
            return;
        if (requireAir.get() && !BlockUtils.canPlace(broken))
            return;

        FindItemResult fir = switch (itemMode.get()) {
            case Cobweb -> ensureInHotbarSingle(class_1802.field_8786);
            case Ladder -> ensureInHotbarSingle(class_1802.field_8121);
            case Button -> ensureInHotbarByTag(class_3489.field_15551);
        };
        if (fir == null)
            return;

        placeAt(broken, fir);
    }

    private boolean isFood(class_1799 stack) {
        return stack != null && !stack.method_7960() && stack.method_58694(class_9334.field_50075) != null;
    }

    private class_2338 pickBrokenSlot() {
        class_2338 chosen = null;
        double bestDist = Double.MAX_VALUE;

        for (class_2338 p : lockedSurround) {
            if (!BlockUtils.canPlace(p))
                continue;
            if (!preferClosestSide.get())
                return p;

            double d = mc.field_1724.method_5707(class_243.method_24953(p));
            if (d < bestDist) {
                bestDist = d;
                chosen = p;
            }
        }
        return chosen;
    }

    private class_2338[] surroundPositions(class_2338 feet) {
        return new class_2338[] { feet.method_10095(), feet.method_10072(), feet.method_10078(), feet.method_10067() };
    }

    private boolean allSolid(class_2338[] positions) {
        for (class_2338 p : positions)
            if (!isSolid(p))
                return false;
        return true;
    }

    private boolean isSolid(class_2338 pos) {
        var s = mc.field_1687.method_8320(pos);
        if (s.method_26215())
            return false;
        return !s.method_26220(mc.field_1687, pos).method_1110();
    }

    private class_1657 findNearestTarget() {
        class_1657 best = null;
        double bestDist = Double.MAX_VALUE;

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724)
                continue;
            if (!p.method_5805())
                continue;
            if (ignoreFriends.get() && Friends.get().isFriend(p))
                continue;
            if (ignoreNaked.get() && isNaked(p))
                continue;

            double d = mc.field_1724.method_5739(p);
            if (d <= range.get() && d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    private boolean isNaked(class_1657 p) {
        return isEmpty(p.method_6118(class_1304.field_6169))
                && isEmpty(p.method_6118(class_1304.field_6174))
                && isEmpty(p.method_6118(class_1304.field_6172))
                && isEmpty(p.method_6118(class_1304.field_6166));
    }

    private boolean isEmpty(class_1799 s) {
        return s == null || s.method_7960();
    }

    private void placeAt(class_2338 pos, FindItemResult fir) {
        // Reset SpeedMine Logic
        NovaKeybindUtils.pressKey(resetKey.get(), 2);

        if (rotate.get()) {
            Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), 5,
                    () -> BlockUtils.place(pos, fir, true, 50, true, true, silentSwap.get()));
        } else {
            BlockUtils.place(pos, fir, false, 50, true, true, silentSwap.get());
        }
    }

    private FindItemResult ensureInHotbarSingle(class_1792 item) {
        FindItemResult hb = InvUtils.findInHotbar(item);
        if (hb.found())
            return hb;

        if (grabFromInventory.get()) {
            int src = findMainSlot(item);
            if (src != -1) {
                int slot = clampHotbar(grabHotbarSlot.get());
                InvUtils.move().from(src).toHotbar(slot);
                FindItemResult recheck = InvUtils.findInHotbar(item);
                if (recheck.found())
                    return recheck;
            }
        }
        return null;
    }

    private FindItemResult ensureInHotbarByTag(class_6862<class_1792> tag) {
        for (int i = 0; i <= 8; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (!s.method_7960() && s.method_31573(tag)) {
                FindItemResult hb = InvUtils.findInHotbar(s.method_7909());
                if (hb.found())
                    return hb;
            }
        }

        if (!grabFromInventory.get())
            return null;

        int src = findMainSlotByTag(tag);
        if (src != -1) {
            class_1792 movedItem = mc.field_1724.method_31548().method_5438(src).method_7909();
            int slot = clampHotbar(grabHotbarSlot.get());
            InvUtils.move().from(src).toHotbar(slot);
            FindItemResult recheck = InvUtils.findInHotbar(movedItem);
            if (recheck.found())
                return recheck;

            for (int i = 0; i <= 8; i++) {
                class_1799 s = mc.field_1724.method_31548().method_5438(i);
                if (!s.method_7960() && s.method_31573(tag)) {
                    FindItemResult hb = InvUtils.findInHotbar(s.method_7909());
                    if (hb.found())
                        return hb;
                }
            }
        }
        return null;
    }

    private void performPreSwapIfNeeded() {
        if (!preSwapOnEnable.get() || mc.field_1724 == null)
            return;

        if (itemMode.get() == PlaceItem.Button) {
            if (hotbarHasAnyByTag(class_3489.field_15551)) {
                didPreSwap = false;
                return;
            }
            int src = findMainSlotByTag(class_3489.field_15551);
            if (src == -1) {
                didPreSwap = false;
                return;
            }
            doPreSwapFrom(src);
            return;
        }

        class_1792 need = (itemMode.get() == PlaceItem.Cobweb) ? class_1802.field_8786 : class_1802.field_8121;
        if (InvUtils.findInHotbar(need).found()) {
            didPreSwap = false;
            return;
        }
        int src = findMainSlot(need);
        if (src == -1) {
            didPreSwap = false;
            return;
        }
        doPreSwapFrom(src);
    }

    private void doPreSwapFrom(int srcSlot) {
        int targetHotbar = clampHotbar(grabHotbarSlot.get());
        class_1799 existing = mc.field_1724.method_31548().method_5438(targetHotbar);

        stashedHotbarToMainSlot = -1;
        if (!existing.method_7960() && stashOldHotbar.get()) {
            int emptyMain = firstEmptyMainSlot();
            if (emptyMain != -1) {
                InvUtils.move().from(targetHotbar).to(emptyMain);
                stashedHotbarToMainSlot = emptyMain;
            }
        }

        InvUtils.move().from(srcSlot).toHotbar(targetHotbar);

        didPreSwap = true;
        preSwapSourceMainSlot = srcSlot;
        preSwapHotbarSlot = targetHotbar;
    }

    private void undoPreSwapIfNeeded() {
        if (!didPreSwap || mc.field_1724 == null)
            return;

        class_1799 inHotbar = mc.field_1724.method_31548().method_5438(preSwapHotbarSlot);
        if (!inHotbar.method_7960()) {
            int dest = preSwapSourceMainSlot;
            if (dest < 9 || dest > 35 || !mc.field_1724.method_31548().method_5438(dest).method_7960())
                dest = firstEmptyMainSlot();
            if (dest != -1)
                InvUtils.move().from(preSwapHotbarSlot).to(dest);
        }

        if (stashedHotbarToMainSlot != -1) {
            class_1799 stashed = mc.field_1724.method_31548().method_5438(stashedHotbarToMainSlot);
            if (!stashed.method_7960()) {
                InvUtils.move().from(stashedHotbarToMainSlot).to(preSwapHotbarSlot);
            }
        }

        didPreSwap = false;
        preSwapSourceMainSlot = -1;
        preSwapHotbarSlot = -1;
        stashedHotbarToMainSlot = -1;
    }

    private int clampHotbar(int v) {
        return Math.max(0, Math.min(8, v));
    }

    private int firstEmptyMainSlot() {
        for (int i = 9; i <= 35; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960())
                return i;
        }
        return -1;
    }

    private boolean hotbarHasAnyByTag(class_6862<class_1792> tag) {
        for (int i = 0; i <= 8; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (!s.method_7960() && s.method_31573(tag))
                return true;
        }
        return false;
    }

    private int findMainSlot(class_1792 it) {
        for (int i = 9; i <= 35; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (!s.method_7960() && s.method_7909() == it)
                return i;
        }
        return -1;
    }

    private int findMainSlotByTag(class_6862<class_1792> tag) {
        for (int i = 9; i <= 35; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (!s.method_7960() && s.method_31573(tag))
                return i;
        }
        return -1;
    }
}
