package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.meteorclient.mixininterface.IChatHud;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1778;
import net.minecraft.class_1786;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3965;

public class AutoTNTplus extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("target-range").defaultValue(4).min(0).sliderMax(6).build());

    private final Setting<Integer> pillarDelay = sgGeneral.add(new IntSetting.Builder()
            .name("pillar-delay").defaultValue(30).min(0).sliderMax(100).build());

    private final Setting<Integer> tntDelay = sgGeneral.add(new IntSetting.Builder()
            .name("tnt-delay").defaultValue(50).min(0).sliderMax(100).build());

    private final Setting<Integer> ignitionDelay = sgGeneral.add(new IntSetting.Builder()
            .name("ignition-delay").defaultValue(1).min(0).sliderMax(20).build());

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate").defaultValue(true).build());

    private final Setting<Boolean> useFlintAndSteel = sgGeneral.add(new BoolSetting.Builder()
            .name("Flint & Steel").defaultValue(true).build());

    private final Setting<Boolean> useFireCharge = sgGeneral.add(new BoolSetting.Builder()
            .name("Fire Charge").defaultValue(false).build());

    private final Setting<Boolean> airPlace = sgGeneral.add(new BoolSetting.Builder()
            .name("Air Place").defaultValue(false).build());

    private final Setting<Boolean> placeSupport = sgGeneral.add(new BoolSetting.Builder()
            .name("Place Support").defaultValue(true).build());

    private class_1657 target;
    private class_2338 basePos;
    private class_2338 tntPos;
    private class_2338 lastTargetPos;
    private class_2350 placedDirection;
    private int currentPillarHeight = 2;
    private int cooldown = 0;
    private int igniteTicks = 0;

    // Chat cooldowns (2 seconds = 40 ticks)
    private int tntCooldown = 0;
    private int obsidianCooldown = 0;
    private int igniterCooldown = 0;
    private int movedCooldown = 0;

    public AutoTNTplus() {
        super(Addon.CATEGORY, "auto-tnt-plus", "Automatically drop tnt on enemies.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("AutoTNTplus", true);
        reset();
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("AutoTNTplus", false);
    }

    private void reset() {
        basePos = null;
        tntPos = null;
        placedDirection = null;
        lastTargetPos = null;
        currentPillarHeight = 2;
        cooldown = 0;
        igniteTicks = 0;
    }

    @EventHandler
    public void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        // Decrement chat cooldowns
        if (tntCooldown > 0)
            tntCooldown--;
        if (obsidianCooldown > 0)
            obsidianCooldown--;
        if (igniterCooldown > 0)
            igniterCooldown--;
        if (movedCooldown > 0)
            movedCooldown--;

        if (TargetUtils.isBadTarget(target, range.get())) {
            target = TargetUtils.getPlayerTarget(range.get(), SortPriority.LowestHealth);
            if (TargetUtils.isBadTarget(target, range.get()))
                return;
            reset();
        }

        class_2338 targetPos = target.method_24515();

        if (lastTargetPos != null && !lastTargetPos.equals(targetPos)) {
            if (movedCooldown == 0) {
                info("Target moved. Resetting.");
                movedCooldown = 40;
            }
            reset();
        }
        lastTargetPos = targetPos;

        FindItemResult obsidian = InvUtils
                .findInHotbar(stack -> class_2248.method_9503(stack.method_7909()) == class_2246.field_10540);
        FindItemResult tnt = InvUtils.findInHotbar(stack -> class_2248.method_9503(stack.method_7909()) == class_2246.field_10375);

        if (!tnt.found()) {
            if (tntCooldown == 0) {
                warning("No TNT found in hotbar!");
                tntCooldown = 40;
            }
            return;
        }

        if (!airPlace.get() && !obsidian.found() && placeSupport.get()) {
            if (obsidianCooldown == 0) {
                warning("Missing obsidian for pillar.");
                obsidianCooldown = 40;
            }
            return;
        }

        if (airPlace.get()) {
            tntPos = targetPos.method_10086(2);
        } else if (placeSupport.get()) {
            if (placedDirection == null || basePos == null || tntPos == null) {
                for (class_2350 dir : class_2350.class_2353.field_11062) {
                    class_2338 surround = targetPos.method_10093(dir);
                    class_2338 base = surround.method_10084();

                    boolean is2Tall = mc.field_1687.method_8320(base).method_27852(class_2246.field_10540)
                            && mc.field_1687.method_8320(base.method_10084()).method_27852(class_2246.field_10540);
                    if (is2Tall || !mc.field_1687.method_8320(surround).method_26215()) {
                        placedDirection = dir;
                        basePos = base;
                        currentPillarHeight = 2;
                        tntPos = targetPos.method_10086(currentPillarHeight);
                        break;
                    }
                }
            }

            if (basePos == null || tntPos == null || placedDirection == null)
                return;

            for (int i = 0; i < currentPillarHeight; i++) {
                class_2338 pos = basePos.method_10086(i);
                if (!mc.field_1687.method_8320(pos).method_27852(class_2246.field_10540)) {
                    BlockUtils.place(pos, obsidian, 0);
                    cooldown = pillarDelay.get();
                    return;
                }
            }
        }

        if (tntPos != null && mc.field_1687.method_8320(tntPos).method_45474()) {
            BlockUtils.place(tntPos, tnt, 0);
            cooldown = tntDelay.get();
            igniteTicks = 0;
        }

        if (igniteTicks >= ignitionDelay.get()) {
            igniteNearbyTNT();
            igniteTicks = 0;
        }
        igniteTicks++;
    }

    private void igniteNearbyTNT() {
        class_2338 playerPos = mc.field_1724.method_24515();

        // The igniter does not change while we scan, so look it up once.
        FindItemResult item = InvUtils.findInHotbar(stack -> {
            if (stack.method_7909() instanceof class_1786) {
                return useFlintAndSteel.get();
            } else if (stack.method_7909() instanceof class_1778) {
                return useFireCharge.get();
            }
            return false;
        });

        if (!item.found()) {
            if (igniterCooldown == 0) {
                warning("No igniter found!");
                igniterCooldown = 40;
            }
            return;
        }

        for (int x = -4; x <= 4; x++) {
            for (int y = -4; y <= 4; y++) {
                for (int z = -4; z <= 4; z++) {
                    class_2338 pos = playerPos.method_10069(x, y, z);
                    if (mc.field_1687.method_8320(pos).method_26204() instanceof net.minecraft.class_2530) {
                        InvUtils.swap(item.slot(), false);
                        class_3965 hit = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);

                        if (rotate.get())
                            lookAt(pos);

                        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
                        mc.field_1724.method_6104(class_1268.field_5808);
                        return;
                    }
                }
            }
        }
    }

    private void lookAt(class_2338 pos) {
        class_243 center = class_243.method_24953(pos);
        mc.field_1724.method_5702(net.minecraft.class_2183.class_2184.field_9851, center);
    }

    @Override
    public String getInfoString() {
        return target != null ? EntityUtils.getName(target) : null;
    }

    // --- Helpers from StainlessModule ported ---

    @Override
    public void info(String message, Object... args) {
        sendInfoMsg(args.length == 0 ? message : String.format(message, args));
    }

    @Override
    public void warning(String message, Object... args) {
        NovaChatUtils.sendInfoMsg("AutoTNTplus",
                class_124.field_1054 + (args.length == 0 ? message : String.format(message, args)));
    }

    private void sendInfoMsg(String text) {
        NovaChatUtils.sendInfoMsg("AutoTNTplus", text);
    }

    private void sendColoredMsg(String text, class_124 color, int id) {
        if (!shouldChat())
            return;
        ChatUtils.forceNextPrefixClass(getClass());
        class_2561 msg = class_2561.method_43473()
                .method_10852(class_2561.method_43470("[AutoTntPlus] ").method_27692(class_124.field_1061))
                .method_10852(class_2561.method_43470(text).method_27692(color));
        sendMessage(msg, id);
    }

    private boolean shouldChat() {
        return mc != null && mc.field_1687 != null && mc.field_1705 != null && mc.field_1705.method_1743() != null;
    }

    private void sendMessage(class_2561 text, int id) {
        ((IChatHud) mc.field_1705.method_1743()).meteor$add(text, id);
    }
}
