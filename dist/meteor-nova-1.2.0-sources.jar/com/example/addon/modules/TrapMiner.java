package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import com.example.addon.utils.NovaKeybindUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2292;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_8810;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import org.lwjgl.glfw.GLFW;

public class TrapMiner extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("range")
            .description("Range to detect enemies.")
            .defaultValue(5.0)
            .build());

    private final Setting<BreakMode> breakMode = sgGeneral.add(new EnumSetting.Builder<BreakMode>()
            .name("break-mode")
            .description("How to break blocks under enemies.")
            .defaultValue(BreakMode.Packet)
            .build());

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Rotate toward the block being broken.")
            .defaultValue(true)
            .build());

    private final Setting<Keybind> resetKey = sgGeneral.add(new KeybindSetting.Builder()
            .name("reset-key")
            .description("Key to toggle SpeedMine (Reset InstaMine).")
            .defaultValue(Keybind.fromKey(GLFW.GLFW_KEY_4))
            .build());

    public TrapMiner() {
        super(Addon.CATEGORY, "trap-miner",
                "Breaks buttons, torches, and webs inside enemy hitbox (helps concrete traps).");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("TrapMiner", true);
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("TrapMiner", false);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1687 == null || mc.field_1724 == null)
            return;

        for (class_1297 entity : mc.field_1687.method_18456()) {
            if (!(entity instanceof class_1657 player))
                continue;
            if (player == mc.field_1724 || player.method_7325() || player.method_68878())
                continue;
            if (mc.field_1724.method_5739(player) > range.get())
                continue;

            class_2338 blockPos = player.method_24515();
            class_2248 block = mc.field_1687.method_8320(blockPos).method_26204();

            // Already trapped in concrete? Don't break (keep them trapped)
            if (block instanceof class_2292
                    || mc.field_1687.method_8320(blockPos.method_10084()).method_26204() instanceof class_2292
                    || mc.field_1687.method_8320(blockPos.method_10074()).method_26204() instanceof class_2292) {
                continue;
            }

            if (isTrapObstacle(block)) {
                if (rotate.get()) {
                    Rotations.rotate(Rotations.getYaw(blockPos.method_46558()),
                            Rotations.getPitch(blockPos.method_46558()));
                }

                if (breakMode.get() == BreakMode.Normal) {
                    mc.field_1761.method_2902(blockPos, class_2350.field_11036);
                    mc.field_1724.method_6104(class_1268.field_5808);
                } else {
                    // Reset SpeedMine if configured
                    NovaKeybindUtils.pressKey(resetKey.get(), 2);

                    mc.field_1761.method_2910(blockPos, class_2350.field_11036);
                    mc.field_1724.method_6104(class_1268.field_5808);
                }

                // Break one at a time per tick to avoid spam kicks
                break;
            }
        }
    }

    private boolean isTrapObstacle(class_2248 block) {
        return block instanceof class_2269
                || block instanceof class_8810
                || block == class_2246.field_10343
                || block == class_2246.field_10589;
    }

    public enum BreakMode {
        Normal,
        Packet
    }
}
