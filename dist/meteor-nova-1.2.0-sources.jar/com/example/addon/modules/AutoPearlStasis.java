package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.mixininterface.IChatHud;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1684;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_3612;
import net.minecraft.class_3965;
import net.minecraft.util.math.*;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class AutoPearlStasis extends Module {
    // ===== General =====
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public enum Mode {
        MAIN, ALT
    }

    public enum ThrowMode {
        PRECISE_AIM, SIMPLE_DOWN
    }

    public enum ProxAltTarget {
        ALT1, ALT2, BOTH
    }

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("mode").description("Run as your main account (sender) or alt account (receiver).")
            .defaultValue(Mode.MAIN).build());

    // ===== MAIN (Input) – Alt #1 =====
    private final SettingGroup sgMainAlt1 = settings.createGroup("Main (Alt #1)");

    private final Setting<String> altName1 = sgMainAlt1.add(new StringSetting.Builder()
            .name("alt1-name").description("Alt #1 username to /msg.").defaultValue("").build());

    private final Setting<Integer> threshold1 = sgMainAlt1.add(new IntSetting.Builder()
            .name("alt1-totem-threshold")
            .description("Auto-sends to Alt #1 when your totems drop to this count (or below).")
            .defaultValue(1).min(0).max(64).sliderMin(0).sliderMax(64).build());

    private final Setting<Boolean> forceTeleport1 = sgMainAlt1.add(new BoolSetting.Builder()
            .name("alt1-force-teleport").description("Forces a /msg to Alt #1 this tick, then resets.")
            .defaultValue(false).build());

    private final Setting<String> forceKey1 = sgMainAlt1.add(new StringSetting.Builder()
            .name("alt1-force-key")
            .description("Key to instantly force-send to Alt #1 (e.g., G, F4, SPACE). Leave blank to disable.")
            .defaultValue("").build());

    // ===== MAIN (Input) – Alt #2 =====
    private final SettingGroup sgMainAlt2 = settings.createGroup("Main (Alt #2)");

    private final Setting<String> altName2 = sgMainAlt2.add(new StringSetting.Builder()
            .name("alt2-name").description("Alt #2 username to /msg.").defaultValue("").build());

    private final Setting<Integer> threshold2 = sgMainAlt2.add(new IntSetting.Builder()
            .name("alt2-totem-threshold")
            .description("Auto-sends to Alt #2 when your totems drop to this count (or below).")
            .defaultValue(1).min(0).max(64).sliderMin(0).sliderMax(64).build());

    private final Setting<Boolean> forceTeleport2 = sgMainAlt2.add(new BoolSetting.Builder()
            .name("alt2-force-teleport").description("Forces a /msg to Alt #2 this tick, then resets.")
            .defaultValue(false).build());

    private final Setting<String> forceKey2 = sgMainAlt2.add(new StringSetting.Builder()
            .name("alt2-force-key")
            .description("Key to instantly force-send to Alt #2 (e.g., H, F5, LEFT_SHIFT). Leave blank to disable.")
            .defaultValue("").build());

    // ===== Proximity Trigger (MAIN) =====
    private final SettingGroup sgProx = settings.createGroup("Proximity Trigger");

    private final Setting<Boolean> enableProx = sgProx.add(new BoolSetting.Builder()
            .name("enable").description("Force-teleport when a target player enters render distance.")
            .defaultValue(false).build());

    private final Setting<Integer> proxRadius = sgProx.add(new IntSetting.Builder()
            .name("radius").description("Max distance to check (blocks).")
            .defaultValue(64).min(8).max(160).sliderMin(8).sliderMax(160).visible(enableProx::get).build());

    private final Setting<List<String>> proxNameList = sgProx.add(new StringListSetting.Builder()
            .name("names-list")
            .description("Click + to add player names. Leave empty = uses 'match-anyone-when-empty'.")
            .defaultValue(new ArrayList<>()).visible(enableProx::get).build());

    private final Setting<String> proxNames = sgProx.add(new StringSetting.Builder()
            .name("names-comma").description("Comma-separated names if you prefer one text box.")
            .defaultValue("").visible(enableProx::get).build());

    private final Setting<Boolean> proxMatchAnyone = sgProx.add(new BoolSetting.Builder()
            .name("match-anyone-when-empty").description("If no names are configured, match anyone in radius.")
            .defaultValue(false).visible(enableProx::get).build());

    private final Setting<Integer> proxWarmup = sgProx.add(new IntSetting.Builder()
            .name("prox-warmup-ticks")
            .description("Suppress proximity triggers for this many ticks after joining a world.")
            .defaultValue(120).min(0).max(400).sliderMin(0).sliderMax(400).visible(enableProx::get).build());

    private final Setting<ProxAltTarget> proxTargetAlt = sgProx.add(new EnumSetting.Builder<ProxAltTarget>()
            .name("send-to").description("Which alt to contact when proximity triggers.")
            .defaultValue(ProxAltTarget.ALT1).visible(enableProx::get).build());

    private final Setting<Integer> proxCooldown = sgProx.add(new IntSetting.Builder()
            .name("cooldown-ticks").description("Minimum ticks between proximity triggers.")
            .defaultValue(60).min(0).max(400).sliderMin(0).sliderMax(400).visible(enableProx::get).build());

    private final Setting<Boolean> proxChatFeedback = sgProx.add(new BoolSetting.Builder()
            .name("chat-feedback").description("Announce detected player name & coords in chat when triggering.")
            .defaultValue(true).visible(enableProx::get).build());

    // NEW: optional motion requirement toggle (default off)
    private final Setting<Boolean> proxRequireMotion = sgProx.add(new BoolSetting.Builder()
            .name("require-motion")
            .description("Only trigger if you've been moving recently. Disable to trigger while standing still.")
            .defaultValue(false).visible(enableProx::get).build());

    // ===== ALT (Output) – Receiver =====
    private final SettingGroup sgAlt = settings.createGroup("Alt (Receiver)");

    private final Setting<String> mainName = sgAlt.add(new StringSetting.Builder()
            .name("main-account-name").description("Enter Main Account Username Here -->")
            .defaultValue("").build());

    private final Setting<Integer> altTriggerThreshold = sgAlt.add(new IntSetting.Builder()
            .name("totem-threshold").description("When received count is <= this, flip nearest trapdoor.")
            .defaultValue(1).min(0).max(64).sliderMin(0).sliderMax(64).build());

    private final Setting<Boolean> altSendConfirm = sgAlt.add(new BoolSetting.Builder()
            .name("send-tp-confirm").description("After flipping a trapdoor, whisper MAIN a 'tp-ok' confirmation.")
            .defaultValue(true).build());

    private final Setting<Integer> altReopenDelay = sgAlt.add(new IntSetting.Builder()
            .name("reopen-delay-ticks")
            .description("After using a stasis, wait this many ticks then ensure the trapdoor is open again.")
            .defaultValue(25).min(0).max(200).sliderMin(0).sliderMax(200).build());

    // ===== Stasis Assist (MAIN: after teleport) =====
    private final SettingGroup sgAssist = settings.createGroup("Stasis Assist");

    private final Setting<Boolean> autoApproach = sgAssist.add(new BoolSetting.Builder()
            .name("auto-approach-stasis")
            .description("After teleport, walk to the block edge next to the water, then throw.")
            .defaultValue(true).build());

    private final Setting<Boolean> autoRethrow = sgAssist.add(new BoolSetting.Builder()
            .name("auto-rethrow").description("Automatically pitch down & throw the pearl into the chamber.")
            .defaultValue(true).build());

    private final Setting<Boolean> autoStartNear = sgAssist.add(new BoolSetting.Builder()
            .name("auto-start-when-near").description("If a valid stasis is nearby while idle, auto-start the assist.")
            .defaultValue(true).build());

    private final Setting<ThrowMode> throwMode = sgAssist.add(new EnumSetting.Builder<ThrowMode>()
            .name("throw-mode")
            .description("PRECISE_AIM: face water center & hold short. SIMPLE_DOWN: face water & pitch down.")
            .defaultValue(ThrowMode.SIMPLE_DOWN).build());

    private final Setting<Integer> downPitchDeg = sgAssist.add(new IntSetting.Builder()
            .name("down-pitch-deg").description("Pitch used when aiming down into water.")
            .defaultValue(89).min(82).max(90).sliderMin(82).sliderMax(90).build());

    private final Setting<Integer> pitchHoldTicks = sgAssist.add(new IntSetting.Builder()
            .name("pitch-hold-ticks").description("How long to hard-hold the down pitch so you see it on screen.")
            .defaultValue(20).min(4).max(40).sliderMin(4).sliderMax(40).build());

    private final Setting<Integer> throwWindowTicks = sgAssist.add(new IntSetting.Builder()
            .name("throw-window-ticks").description("How long to attempt throwing before giving up.")
            .defaultValue(40).min(8).max(60).sliderMin(8).sliderMax(60).build());

    private final Setting<Integer> retryGapTicks = sgAssist.add(new IntSetting.Builder()
            .name("retry-gap-ticks").description("Ticks between a second throw attempt if no cooldown was detected.")
            .defaultValue(6).min(3).max(15).sliderMin(3).sliderMax(15).build());

    private final Setting<Boolean> stepBackAfterThrow = sgAssist.add(new BoolSetting.Builder()
            .name("step-back-after-throw")
            .description("Step back after throwing pearl to prevent accidental activation.")
            .defaultValue(true).build());

    private final Setting<Integer> stepBackTicks = sgAssist.add(new IntSetting.Builder()
            .name("step-back-ticks")
            .description("Base ticks to spend stepping back from the stasis. Auto-scales with distance.")
            .defaultValue(10).min(3).max(30).sliderMin(3).sliderMax(30).build());

    private final Setting<Double> stepBackDistance = sgAssist.add(new DoubleSetting.Builder()
            .name("step-back-distance").description("Preferred retreat distance (blocks) from the stasis edge.")
            .defaultValue(2.0).min(0.5).max(3.0).sliderMin(0.5).sliderMax(3.0).build());

    private final Setting<Boolean> sneakWhileAiming = sgAssist.add(new BoolSetting.Builder()
            .name("sneak-while-aiming").description("Hold sneak while aiming/throwing to prevent sliding.")
            .defaultValue(true).build());

    private final Setting<Integer> sneakAimingTicks = sgAssist.add(new IntSetting.Builder()
            .name("sneak-aiming-ticks").description("Ticks to hold sneak while aiming & throwing.")
            .defaultValue(8).min(2).max(20).sliderMin(2).sliderMax(20).build());

    private final Setting<Integer> searchRadius = sgAssist.add(new IntSetting.Builder()
            .name("search-radius").description("Search radius (blocks) for stasis water + trapdoor.")
            .defaultValue(12).min(4).max(24).sliderMin(4).sliderMax(24).build());

    private final Setting<Integer> approachTimeout = sgAssist.add(new IntSetting.Builder()
            .name("approach-timeout-ticks").description("Give up moving after this many ticks (20t = 1s).")
            .defaultValue(360).min(40).max(2000).sliderMin(40).sliderMax(2000).build());

    private final Setting<Double> approachDistance = sgAssist.add(new DoubleSetting.Builder()
            .name("edge-distance").description("How close to the edge to stand before throwing.")
            .defaultValue(0.5).min(0.15).max(0.8).sliderMin(0.15).sliderMax(0.8).build());

    private final Setting<Boolean> useChatConfirm = sgAssist.add(new BoolSetting.Builder()
            .name("use-chat-confirm")
            .description("Start assist after receiving 'tp-ok' from ALT; fallback is distance jump.")
            .defaultValue(true).build());

    private final Setting<Integer> postTpDelay = sgAssist.add(new IntSetting.Builder()
            .name("post-teleport-delay-ticks")
            .description("Wait this many ticks after 'tp-ok' (or teleport jump) before starting.")
            .defaultValue(40).min(0).max(200).sliderMin(0).sliderMax(200).build());

    private final Setting<Integer> pearlVerifyTicks = sgAssist.add(new IntSetting.Builder()
            .name("pearl-verify-ticks")
            .description("Ticks to wait and verify pearl landed in stasis water after throwing.")
            .defaultValue(12).min(5).max(30).sliderMin(5).sliderMax(30).build());

    private final Setting<Boolean> retryOnMiss = sgAssist.add(new BoolSetting.Builder()
            .name("retry-on-miss").description("Retry throwing if pearl doesn't land in stasis water.")
            .defaultValue(true).build());

    private final Setting<Integer> maxRetries = sgAssist.add(new IntSetting.Builder()
            .name("max-retries").description("Maximum number of retry attempts if pearl misses.")
            .defaultValue(2).min(1).max(5).sliderMin(1).sliderMax(5).build());

    private final Setting<Boolean> useBaritone = sgAssist.add(new BoolSetting.Builder()
            .name("use-baritone-if-present").description("Use Baritone for pathing (optional).")
            .defaultValue(true).build());

    private final Setting<Double> surfaceHeadClearance = sgAssist.add(new DoubleSetting.Builder()
            .name("surface-head-clearance")
            .description("Required head height above water surface before leaving SURFACING.")
            .defaultValue(0.60).min(0.20).max(1.20).sliderMin(0.20).sliderMax(1.20).build());

    private final Setting<Boolean> advancedWaterEscape = sgAssist.add(new BoolSetting.Builder()
            .name("advanced-water-escape").description("Use advanced water exit mechanics to climb out reliably.")
            .defaultValue(true).build());

    private final Setting<Boolean> debugChat = sgAssist.add(new BoolSetting.Builder()
            .name("debug-chat").description("Verbose state logs (spammy).")
            .defaultValue(false).build());

    // ===== Water Exit tuning =====
    private final SettingGroup sgWaterExit = settings.createGroup("Water Exit Tuning");

    private final Setting<Integer> exitPitchDeg = sgWaterExit.add(new IntSetting.Builder()
            .name("exit-pitch-deg").description("Pitch down while exiting water (used during pathing/surfacing/boost).")
            .defaultValue(25).min(5).max(60).sliderMin(5).sliderMax(60).build());

    private final Setting<Integer> exitForwardTicks = sgWaterExit.add(new IntSetting.Builder()
            .name("forward-hold-ticks").description("How long to hold W during water exit pulses.")
            .defaultValue(6).min(1).max(20).sliderMin(1).sliderMax(20).build());

    private final Setting<Integer> exitSprintTicks = sgWaterExit.add(new IntSetting.Builder()
            .name("sprint-hold-ticks").description("How long to hold sprint during water exit pulses.")
            .defaultValue(10).min(1).max(20).sliderMin(1).sliderMax(20).build());

    private final Setting<Integer> exitJumpTicks = sgWaterExit.add(new IntSetting.Builder()
            .name("jump-pulse-ticks").description("How long to tap jump during water exit pulses.")
            .defaultValue(2).min(0).max(10).sliderMin(0).sliderMax(10).build());

    // ===== Inventory / Throw source =====
    private final SettingGroup sgInv = settings.createGroup("Inventory");

    private final Setting<Boolean> preferOffhand = sgInv.add(new BoolSetting.Builder()
            .name("prefer-offhand").description("Use offhand pearls if available.")
            .defaultValue(true).build());

    private final Setting<Boolean> silentSwap = sgInv.add(new BoolSetting.Builder()
            .name("silent-swap").description("Temporarily swap to pearls, then swap back after throwing.")
            .defaultValue(true).build());

    private final Setting<Boolean> swapBackOnStricterServers = sgInv.add(new BoolSetting.Builder()
            .name("swap-back-stricter-servers")
            .description(
                    "Move pearls back to original inventory slot after throwing (for servers without silent swap).")
            .defaultValue(true).visible(() -> !silentSwap.get()).build());

    private final Setting<Boolean> pullFromInventory = sgInv.add(new BoolSetting.Builder()
            .name("pull-from-inventory").description("If no pearls in hotbar, pull from main inventory.")
            .defaultValue(true).build());

    private final Setting<Boolean> preferEmptyHotbar = sgInv.add(new BoolSetting.Builder()
            .name("prefer-empty-hotbar").description("Prefer an empty hotbar slot when pulling from inventory.")
            .defaultValue(true).visible(pullFromInventory::get).build());

    private final Setting<Integer> tempHotbarSlot = sgInv.add(new IntSetting.Builder()
            .name("temp-hotbar-slot").description("Fallback hotbar slot [0–8] when pulling from inventory.")
            .defaultValue(8).min(0).max(8).visible(pullFromInventory::get).build());

    // ===== State =====
    private int lastCount = -1;
    private int joinCooldown = 60;
    private boolean key1WasDown = false, key2WasDown = false;

    private enum AssistState {
        IDLE, SEARCH, PATHING, SURFACING, EDGE_ADJUST, THROWING, STEPPING_BACK, VERIFYING, DONE, FAILED
    }

    private AssistState assistState = AssistState.IDLE;

    private class_2338 stasisWater = null, standBlock = null;
    private class_243 standEdgePos = null;

    private int assistTicks = 0;
    private int throwAttemptTicks = 0;

    private boolean thrownThisCycle = false;
    private boolean throwOnceLatch = false;
    private int suppressThrowsTicks = 0;
    private int sneakHoldTicks = 0;

    private double lastEdgeDist = Double.MAX_VALUE;
    private int noProgressTicks = 0, stuckTicks = 0, escapeBoostTicks = 0, surfacingTicks = 0;
    private class_243 lastPos = null;

    private int verifyTicks = 0, retryCount = 0, stasisPearlCountBefore = -1;

    private class_243 stepBackTarget = null;
    private int stepBackTicksRemaining = 0;
    private class_2338 retreatGoalBlock = null;
    private int throwTimer = 0;

    private class_2338 lastTrapdoorUsed = null;
    private int reopenDelayTicks = -1;

    private boolean teleportPending = false;
    private class_243 teleportOrigin = null;
    private int teleportWindowTicks = 0;
    private int postTeleportDelayTicks = -1;

    private int ticksSinceJoin = 0;
    private int proxMotionTicks = 0;

    private int holdForward = 0, holdSprint = 0, holdJump = 0;

    private static final int IDLE_SCAN_INTERVAL = 20;
    private int idleScanTicks = 0;

    // Inventory temp state
    private boolean usingOffhand = false;
    private boolean didSilentSwap = false;
    private boolean didMoveFromInv = false;
    private int movedFromSlot = -1;
    private int movedToHotbar = -1;

    private final Set<UUID> proxSeen = new HashSet<>();
    private int proxCdTicks = 0;

    private AssistState lastLoggedState = AssistState.IDLE;

    private boolean needCleanup = false;

    public AutoPearlStasis() {
        super(Addon.CATEGORY, "auto-pearl-stasis",
                "Instantly Teleports you to your pearl chamber (alt account required).");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("AutoPearlStasis", true);
        throwTimer = 0;
        super.onActivate();
        joinCooldown = 60;
        ticksSinceJoin = 0;
        if (mode.get() == Mode.MAIN) {
            lastCount = countTotems();
            key1WasDown = key2WasDown = false;
            resetAssist();
            teleportPending = false;
            teleportOrigin = null;
            teleportWindowTicks = 0;
            postTeleportDelayTicks = -1;
            proxSeen.clear();
            proxCdTicks = 0;
            proxMotionTicks = 0;
        } else {
            lastTrapdoorUsed = null;
            reopenDelayTicks = -1;
        }
        needCleanup = false;
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("AutoPearlStasis", false);
        super.onDeactivate();
    }

    // ... (rest of onActivate is handled by block replacement if range matches, but
    // I targeted constructor) ...

    /*
     * Since we are replacing the bottom of the file to add helpers,
     * we need to be careful not to delete existing methods if we don't include
     * them.
     * Wait, I should append helpers at the end.
     */

    @EventHandler
    public void onJoin(GameJoinedEvent e) {
        joinCooldown = 60;
        ticksSinceJoin = 0;
        resetAssist();
        lastTrapdoorUsed = null;
        reopenDelayTicks = -1;
        teleportPending = false;
        teleportOrigin = null;
        teleportWindowTicks = 0;
        postTeleportDelayTicks = -1;
        proxSeen.clear();
        proxCdTicks = 0;
        proxMotionTicks = 0;
        needCleanup = false;
    }

    @EventHandler
    public void onTick(TickEvent.Post e) {
        if (mode.get() == Mode.MAIN)
            tickMain();
        else
            tickAlt();
    }

    // ================= MAIN =================
    private void tickMain() {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null)
            return;

        if (needCleanup) {
            cleanupInventoryState();
            needCleanup = false;
        }

        ticksSinceJoin++;

        if (lastPos != null) {
            double dx = mc.field_1724.method_23317() - lastPos.field_1352;
            double dz = mc.field_1724.method_23321() - lastPos.field_1350;
            double sp2 = dx * dx + dz * dz;
            if (sp2 > 0.0025)
                proxMotionTicks = Math.min(40, proxMotionTicks + 1);
        }

        if (joinCooldown > 0) {
            joinCooldown--;
            lastPos = mc.field_1724.method_73189();
            return;
        }
        if (suppressThrowsTicks > 0)
            suppressThrowsTicks--;
        if (proxCdTicks > 0)
            proxCdTicks--;

        // Hotkeys -> force flags
        long handle = mc.method_22683() != null ? mc.method_22683().method_4490() : 0;
        int kc1 = parseKey(forceKey1.get());
        if (handle != 0 && kc1 != GLFW.GLFW_KEY_UNKNOWN) {
            boolean down = GLFW.glfwGetKey(handle, kc1) == GLFW.GLFW_PRESS;
            if (down && !key1WasDown)
                forceTeleport1.set(true);
            key1WasDown = down;
        } else
            key1WasDown = false;

        int kc2 = parseKey(forceKey2.get());
        if (handle != 0 && kc2 != GLFW.GLFW_KEY_UNKNOWN) {
            boolean down = GLFW.glfwGetKey(handle, kc2) == GLFW.GLFW_PRESS;
            if (down && !key2WasDown)
                forceTeleport2.set(true);
            key2WasDown = down;
        } else
            key2WasDown = false;

        // Manual forced teleports
        if (forceTeleport1.get()) {
            sendMessageTo(altName1.get(), Math.max(1, threshold1.get()));
            markTeleportPending();
            forceTeleport1.set(false);
        }
        if (forceTeleport2.get()) {
            sendMessageTo(altName2.get(), Math.max(1, threshold2.get()));
            markTeleportPending();
            forceTeleport2.set(false);
        }

        // Auto-send based on totem change
        int current = countTotems();
        if (current != lastCount) {
            if (current <= threshold1.get()) {
                sendMessageTo(altName1.get(), current);
                markTeleportPending();
            }
            if (current <= threshold2.get()) {
                sendMessageTo(altName2.get(), current);
                markTeleportPending();
            }
        }
        lastCount = current;

        // Proximity trigger
        if (enableProx.get())
            runProximityTrigger();

        // Detect teleport by position jump
        if (teleportPending) {
            if (teleportWindowTicks-- <= 0)
                teleportPending = false;
            else {
                class_243 now = mc.field_1724.method_73189();
                if (now.method_1025(teleportOrigin) > (12 * 12) || Math.abs(now.field_1351 - teleportOrigin.field_1351) > 4.0) {
                    teleportPending = false;
                    postTeleportDelayTicks = postTpDelay.get();
                }
            }
        }

        // Start assist after tp-ok / teleport detection
        if (postTeleportDelayTicks >= 0 && --postTeleportDelayTicks == 0)
            triggerAssist();

        // Optional: auto-start if stasis is already nearby. Scanning is a few
        // thousand block lookups, so only do it a few times a second.
        if (assistState == AssistState.IDLE && autoApproach.get() && autoStartNear.get()
                && --idleScanTicks <= 0) {
            idleScanTicks = IDLE_SCAN_INTERVAL;
            if (findStasisAndEdge()) {
                stasisPearlCountBefore = countPearlsInStasis();
                startPathTo(standBlock);
                assistState = AssistState.PATHING;
                logState();
            }
        }

        // Run assist state machine
        if (assistState != AssistState.IDLE && assistState != AssistState.DONE && assistState != AssistState.FAILED) {
            assistTick();
        }

        if (mc.field_1724 != null)
            lastPos = mc.field_1724.method_73189();
    }

    // === Stainless-styled proximity logic ===
    private void runProximityTrigger() {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null)
            return;

        if (ticksSinceJoin < proxWarmup.get()) {
            apsProxDebug("Disarmed: warmup (" + ticksSinceJoin + "/" + proxWarmup.get() + " ticks)");
            return;
        }

        if (proxCdTicks > 0) {
            apsProxDebug("Cooling down: " + proxCdTicks + " ticks left");
            return;
        }

        if (proxRequireMotion.get() && proxMotionTicks < 6) {
            apsProxDebug("Disarmed: require-motion enabled, proxMotionTicks=" + proxMotionTicks);
            return;
        }

        if (teleportPending) {
            apsProxDebug("Disarmed: teleportPending");
            return;
        }
        if (postTeleportDelayTicks >= 0) {
            apsProxDebug("Disarmed: postTeleportDelayTicks=" + postTeleportDelayTicks);
            return;
        }

        Set<String> watch = buildWatchSet();
        boolean matchAnyone = proxMatchAnyone.get() && watch.isEmpty();
        if (!matchAnyone && watch.isEmpty()) {
            apsProxDebug("No names configured and 'match-anyone-when-empty' is OFF.");
            return;
        }

        int r = Math.max(8, proxRadius.get());
        final double r2 = r * r;

        boolean triggered = false;
        int candidates = 0;

        for (var p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724)
                continue;
            if (p.method_7334() == null)
                continue;

            double d2 = p.method_5858(mc.field_1724);
            if (d2 > r2)
                continue;

            String name = p.method_7334().name();
            if (name == null)
                continue;

            String norm = normalizeName(name);
            if (!matchAnyone && !watch.contains(norm))
                continue;

            candidates++;

            if (proxSeen.contains(p.method_5667())) {
                apsProxDebug("Seen already in radius: " + name);
                continue;
            }

            class_2338 bp = p.method_24515();
            String info = "Proximity: " + name + " @ " + bp.method_10263() + " " + bp.method_10264() + " " + bp.method_10260();

            boolean pinged = false;
            switch (proxTargetAlt.get()) {
                case ALT1 -> {
                    if (!altName1.get().trim().isEmpty()) {
                        sendMessageTo(altName1.get(), Math.max(1, threshold1.get()));
                        pinged = true;
                        if (proxChatFeedback.get())
                            apsInfo(info + " → forced TP via ALT1.");
                    } else if (proxChatFeedback.get())
                        apsInfo(info + " → ALT1 not set.");
                }
                case ALT2 -> {
                    if (!altName2.get().trim().isEmpty()) {
                        sendMessageTo(altName2.get(), Math.max(1, threshold2.get()));
                        pinged = true;
                        if (proxChatFeedback.get())
                            apsInfo(info + " → forced TP via ALT2.");
                    } else if (proxChatFeedback.get())
                        apsInfo(info + " → ALT2 not set.");
                }
                case BOTH -> {
                    boolean any = false;
                    if (!altName1.get().trim().isEmpty()) {
                        sendMessageTo(altName1.get(), Math.max(1, threshold1.get()));
                        any = true;
                    }
                    if (!altName2.get().trim().isEmpty()) {
                        sendMessageTo(altName2.get(), Math.max(1, threshold2.get()));
                        any = true;
                    }
                    pinged = any;
                    if (proxChatFeedback.get())
                        apsInfo(info + (any ? " → forced TP via BOTH." : " → no alts set."));
                }
            }

            if (pinged) {
                markTeleportPending();
                proxSeen.add(p.method_5667());
                proxCdTicks = Math.max(0, proxCooldown.get());
                triggered = true;
                break;
            }
        }

        proxSeen.retainAll(currentPlayerUUIDsInRadius(r2));

        apsProxDebug("Scan: radius=" + r + ", candidatesInRadius=" + candidates
                + ", watch=" + (watch.isEmpty() ? (matchAnyone ? "ANYONE" : "EMPTY") : watch)
                + (triggered ? ", TRIGGERED" : ", no match"));
    }

    // name helpers
    private Set<String> buildWatchSet() {
        Set<String> set = new LinkedHashSet<>();
        List<String> list = proxNameList.get();
        if (list != null && !list.isEmpty()) {
            for (String s : list) {
                String tok = normalizeName(s);
                if (!tok.isEmpty())
                    set.add(tok);
            }
        }
        String raw = proxNames.get();
        if (raw != null && !raw.trim().isEmpty()) {
            for (String s : raw.split(",")) {
                String tok = normalizeName(s);
                if (!tok.isEmpty())
                    set.add(tok);
            }
        }
        return set;
    }

    private String normalizeName(String s) {
        return (s == null) ? "" : s.trim().toLowerCase(Locale.ROOT);
    }

    private Set<UUID> currentPlayerUUIDsInRadius(double r2) {
        Set<UUID> set = new HashSet<>();
        for (var p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724)
                continue;
            if (p.method_7334() == null)
                continue;
            if (p.method_5858(mc.field_1724) <= r2)
                set.add(p.method_5667());
        }
        return set;
    }

    private void markTeleportPending() {
        teleportPending = true;
        teleportOrigin = mc.field_1724.method_73189();
        teleportWindowTicks = 200;
        if (assistState != AssistState.IDLE)
            resetAssist();
        postTeleportDelayTicks = -1;
    }

    private void sendMessageTo(String alt, int count) {
        String name = alt == null ? "" : alt.trim();
        if (!name.isEmpty())
            ChatUtils.sendPlayerMsg("/msg " + name + " " + count + " totem remaining");
    }

    @EventHandler
    public void onMainChat(ReceiveMessageEvent event) {
        if (mode.get() != Mode.MAIN || !useChatConfirm.get())
            return;
        String m = event.getMessage().getString().toLowerCase(Locale.ROOT);

        boolean fromAlt = false;
        String a1 = altName1.get().trim().toLowerCase(Locale.ROOT);
        String a2 = altName2.get().trim().toLowerCase(Locale.ROOT);
        if (!a1.isEmpty() && m.contains(a1))
            fromAlt = true;
        if (!a2.isEmpty() && m.contains(a2))
            fromAlt = true;

        if ((fromAlt && m.contains("tp-ok")) || (!fromAlt && m.contains("tp-ok"))) {
            teleportPending = false;
            postTeleportDelayTicks = postTpDelay.get();
        }
    }

    // ================ ALT ===================
    private void tickAlt() {
        if (reopenDelayTicks >= 0) {
            if (reopenDelayTicks == 0 && lastTrapdoorUsed != null) {
                ensureTrapdoorOpen(lastTrapdoorUsed);
                reopenDelayTicks = -1;
                lastTrapdoorUsed = null;
            } else
                reopenDelayTicks--;
        }
    }

    @EventHandler
    public void onAltChat(ReceiveMessageEvent event) {
        if (mode.get() != Mode.ALT)
            return;

        class_2561 txt = event.getMessage();
        String msg = txt.getString().toLowerCase(Locale.ROOT);
        String main = mainName.get().trim();
        if (main.isEmpty())
            return;

        if (!msg.contains(main.toLowerCase(Locale.ROOT)))
            return;
        if (!msg.contains("totem remaining"))
            return;

        int count = -1;
        for (String w : msg.split(" ")) {
            try {
                count = Integer.parseInt(w);
                break;
            } catch (NumberFormatException ignored) {
            }
        }
        if (count == -1 || count > 64)
            return;

        if (count <= altTriggerThreshold.get()) {
            class_2338 trapdoor = useBestStasisWithPearl();
            if (trapdoor != null) {
                lastTrapdoorUsed = trapdoor;
                reopenDelayTicks = altReopenDelay.get();
                if (altSendConfirm.get()) {
                    String mainUser = mainName.get().trim();
                    if (!mainUser.isEmpty())
                        ChatUtils.sendPlayerMsg("/msg " + mainUser + " tp-ok");
                }
            } else
                infoOnce("No armed stasis (pearl-in-water) found nearby.");
        }
    }

    private class_2338 useBestStasisWithPearl() {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null)
            return null;

        class_2338 base = mc.field_1724.method_24515();
        int r = 8;
        class_2338 bestTrapdoor = null;
        double bestDist = Double.MAX_VALUE;
        class_2338.class_2339 m = new class_2338.class_2339();

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -2; dy <= 3; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    m.method_10103(base.method_10263() + dx, base.method_10264() + dy, base.method_10260() + dz);
                    if (mc.field_1687.method_8316(m).method_15772() != class_3612.field_15910)
                        continue;

                    class_2338 trap = m.method_10084();
                    if (!(mc.field_1687.method_8320(trap).method_26204() instanceof class_2533))
                        continue;
                    if (!detectAnyPearlInWater(m))
                        continue;

                    double d = mc.field_1724.method_73189().method_1025(class_243.method_24953(m));
                    if (d < bestDist) {
                        bestDist = d;
                        bestTrapdoor = trap.method_10062();
                    }
                }
            }
        }

        if (bestTrapdoor == null)
            return null;
        interactTrapdoor(bestTrapdoor);
        return bestTrapdoor;
    }

    private void interactTrapdoor(class_2338 trapdoorPos) {
        if (mc.field_1724 == null || mc.field_1761 == null)
            return;
        // Sending the packet by hand meant a hardcoded sequence of 0, which the
        // server acknowledges against the wrong action and rolls back.
        class_243 hit = class_243.method_24953(trapdoorPos);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808,
                new class_3965(hit, class_2350.field_11036, trapdoorPos, false));
    }

    private void ensureTrapdoorOpen(class_2338 trapdoorPos) {
        if (mc == null || mc.field_1687 == null || trapdoorPos == null)
            return;
        class_2680 s = mc.field_1687.method_8320(trapdoorPos);
        if (!(s.method_26204() instanceof class_2533))
            return;
        Boolean open = s.method_11654(class_2533.field_11631);
        if (open != null && !open)
            interactTrapdoor(trapdoorPos);
    }

    // ============== Assist (MAIN) ==============
    private void triggerAssist() {
        if (!autoApproach.get())
            return;
        assistState = AssistState.SEARCH;
        assistTicks = 0;
        throwAttemptTicks = 0;
        thrownThisCycle = false;
        throwOnceLatch = false;
        suppressThrowsTicks = 0;
        sneakHoldTicks = 0;
        verifyTicks = 0;
        retryCount = 0;
        stasisPearlCountBefore = -1;
        lastEdgeDist = Double.MAX_VALUE;
        noProgressTicks = 0;
        stuckTicks = 0;
        escapeBoostTicks = 0;
        surfacingTicks = 0;
        lastPos = mc.field_1724 != null ? mc.field_1724.method_73189() : null;
        stasisWater = null;
        standBlock = null;
        standEdgePos = null;
        stepBackTarget = null;
        retreatGoalBlock = null;
        cleanupInventoryState();
        releaseSneak();
        releaseAllMoveKeys();
        needCleanup = false;
        logState();
    }

    private void resetAssist() {
        assistState = AssistState.IDLE;
        assistTicks = 0;
        throwAttemptTicks = 0;
        thrownThisCycle = false;
        throwOnceLatch = false;
        suppressThrowsTicks = 0;
        sneakHoldTicks = 0;
        verifyTicks = 0;
        retryCount = 0;
        stasisPearlCountBefore = -1;
        lastEdgeDist = Double.MAX_VALUE;
        noProgressTicks = 0;
        stuckTicks = 0;
        escapeBoostTicks = 0;
        surfacingTicks = 0;
        lastPos = null;
        stasisWater = null;
        standBlock = null;
        standEdgePos = null;
        stepBackTarget = null;
        retreatGoalBlock = null;
        cleanupInventoryState();
        releaseSneak();
        releaseAllMoveKeys();
        needCleanup = false;
        logState();
    }

    private void assistTick() {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) {
            cleanupInventoryState();
            resetAssist();
            return;
        }
        assistTicks++;

        switch (assistState) {
            case SEARCH -> {
                if (!findStasisAndEdge()) {
                    infoOnce("No stasis found in radius.");
                    assistState = AssistState.FAILED;
                    logState();
                    break;
                }
                stasisPearlCountBefore = countPearlsInStasis();
                startPathTo(standBlock);
                assistState = AssistState.PATHING;
                logState();
            }

            case PATHING -> {
                if (standEdgePos != null)
                    walkTowardExact(standEdgePos);

                if (isInWater()) {
                    faceTowardXZ(standEdgePos);
                    mc.field_1724.method_36457(-exitPitchDeg.get().floatValue());
                    pressForward(exitForwardTicks.get());
                    pressSprint(exitSprintTicks.get());
                    pressJump(exitJumpTicks.get());
                    waterEscapeWatchdog();
                    break;
                }

                if (!isInWater() && isAtEdge()) {
                    stopPath();
                    assistState = AssistState.EDGE_ADJUST;
                    logState();
                } else if (assistTicks > approachTimeout.get()) {
                    stopPath();
                    assistState = AssistState.FAILED;
                    logState();
                }
            }

            case SURFACING -> {
                if (!isInWater() || isHeadAboveSurface()) {
                    assistState = AssistState.PATHING;
                    logState();
                    break;
                }
                mc.field_1724.method_36457(-exitPitchDeg.get().floatValue());
                faceTowardXZ(standEdgePos);
                pressForward(exitForwardTicks.get());
                pressSprint(exitSprintTicks.get());
                pressJump(exitJumpTicks.get());
                if (--surfacingTicks <= 0) {
                    assistState = AssistState.PATHING;
                    logState();
                }
            }

            case EDGE_ADJUST -> {
                if (standEdgePos != null) {
                    class_243 snap = snapPointOnEdge(standEdgePos);
                    walkTowardExact(snap);
                    if (stasisWater != null)
                        faceTowardXZ(class_243.method_24953(stasisWater));
                }
                waterEscapeWatchdog();

                if (isInWater()) {
                    assistState = AssistState.SURFACING;
                    surfacingTicks = 10;
                    logState();
                    break;
                }

                if (isAtEdge()) {
                    releaseAllMoveKeys();
                    if (sneakWhileAiming.get() && sneakHoldTicks <= 0) {
                        pressSneak();
                        sneakHoldTicks = sneakAimingTicks.get();
                    }

                    mc.field_1724.method_36457(downPitchDeg.get().floatValue());

                    if (!autoRethrow.get()) {
                        assistState = AssistState.DONE;
                        logState();
                        break;
                    }

                    if (!ensurePearlReady()) {
                        cleanupInventoryState();
                        assistState = AssistState.FAILED;
                        logState();
                        break;
                    }

                    throwAttemptTicks = throwWindowTicks.get();
                    throwOnceLatch = false;
                    suppressThrowsTicks = 0;
                    assistState = AssistState.THROWING;
                    logState();
                } else if (assistTicks > approachTimeout.get()) {
                    assistState = AssistState.FAILED;
                    logState();
                }
            }

            case THROWING -> {
                releaseAllMoveKeys();

                if (stasisWater != null)
                    faceTowardXZ(class_243.method_24953(stasisWater));
                float targetPitch = downPitchDeg.get().floatValue();
                mc.field_1724.method_36457(targetPitch);
                mc.method_1562().method_52787(new class_2828.class_2831(
                        mc.field_1724.method_36454(), targetPitch, mc.field_1724.method_24828(), false));

                if (isInWater()) {
                    if (--throwAttemptTicks <= 0) {
                        cleanupInventoryState();
                        assistState = AssistState.FAILED;
                        logState();
                    }
                    break;
                }

                if (!throwOnceLatch && suppressThrowsTicks == 0 && !pearlOnCooldown()) {
                    if (!ensurePearlReady()) {
                        if (--throwAttemptTicks <= 0) {
                            cleanupInventoryState();
                            assistState = AssistState.FAILED;
                            logState();
                        }
                        break;
                    }

                    class_1268 hand = usingOffhand ? class_1268.field_5810 : class_1268.field_5808;

                    Runnable doThrow = () -> {
                        if (mc.field_1761 != null) {
                            mc.field_1761.method_2919(mc.field_1724, hand);
                            throwOnceLatch = true;
                            thrownThisCycle = true;
                            suppressThrowsTicks = 40;
                            needCleanup = true;
                            apsDebug("Pearl thrown.");
                        }
                    };

                    doThrow.run();
                }

                if (throwOnceLatch) {
                    if (stepBackAfterThrow.get()) {
                        calculateStepBackTarget();
                        if (useBaritone.get() && retreatGoalBlock != null)
                            startPathTo(retreatGoalBlock);
                        stepBackTicksRemaining = Math.max(stepBackTicksRemaining, stepBackTicks.get());
                        assistState = AssistState.STEPPING_BACK;
                    } else {
                        verifyTicks = pearlVerifyTicks.get();
                        assistState = AssistState.VERIFYING;
                    }
                    logState();
                    break;
                }

                if (--throwAttemptTicks <= 0) {
                    cleanupInventoryState();
                    assistState = AssistState.FAILED;
                    logState();
                }

                if (sneakHoldTicks > 0) {
                    sneakHoldTicks--;
                    if (sneakHoldTicks == 0)
                        releaseSneak();
                }
            }

            case STEPPING_BACK -> {
                if (!useBaritone.get() || retreatGoalBlock == null) {
                    if (stepBackTarget != null)
                        stepBackFromStasis();
                }
                if (--stepBackTicksRemaining <= 0 || hasReachedStepBackTarget()) {
                    if (useBaritone.get())
                        stopPath();
                    verifyTicks = pearlVerifyTicks.get();
                    assistState = AssistState.VERIFYING;
                    logState();
                }
            }

            case VERIFYING -> {
                if (--verifyTicks <= 0) {
                    boolean pearlInStasis = checkPearlIncreasedInStasis()
                            || (stasisWater != null && detectAnyPearlInWater(stasisWater));

                    boolean likelyThrown = thrownThisCycle && pearlOnCooldown();

                    if (pearlInStasis || likelyThrown) {
                        assistState = AssistState.DONE;
                    } else if (retryOnMiss.get() && retryCount < maxRetries.get()) {
                        retryCount++;
                        stasisPearlCountBefore = countPearlsInStasis();
                        if (!ensurePearlReady()) {
                            cleanupInventoryState();
                            assistState = AssistState.FAILED;
                            logState();
                            break;
                        }
                        throwAttemptTicks = throwWindowTicks.get();
                        throwOnceLatch = false;
                        suppressThrowsTicks = 0;
                        assistState = AssistState.THROWING;
                    } else {
                        assistState = thrownThisCycle ? AssistState.DONE : AssistState.FAILED;
                    }
                    logState();
                }
            }

            case DONE, FAILED -> {
                cleanupInventoryState();
                resetAssist();
            }

            default -> {
                cleanupInventoryState();
                assistState = AssistState.FAILED;
                logState();
            }
        }

        maintainMovementKeys();
        if (mc.field_1724 != null)
            lastPos = mc.field_1724.method_73189();
    }

    // ==== Silent-swap & inventory handling ====
    private boolean ensurePearlReady() {
        if (mc.field_1724 == null || mc.field_1761 == null)
            return false;

        cleanupInventoryState(); // Ensure clean state before new cycle
        usingOffhand = false;

        if (preferOffhand.get() && mc.field_1724.method_6079().method_7909() == class_1802.field_8634) {
            usingOffhand = true;
            apsDebug("Using offhand pearl.");
            return true;
        }

        if (mc.field_1724.method_6047().method_7909() == class_1802.field_8634) {
            apsDebug("Already holding pearl in main hand.");
            return true;
        }

        FindItemResult hotbarPearl = InvUtils.findInHotbar(class_1802.field_8634);
        if (hotbarPearl.found()) {
            if (silentSwap.get()) {
                apsDebug("Silent-swapping to hotbar slot " + hotbarPearl.slot());
                InvUtils.swap(hotbarPearl.slot(), true);
                didSilentSwap = true;
            } else {
                apsDebug("Swapping to hotbar slot " + hotbarPearl.slot());
                InvUtils.swap(hotbarPearl.slot(), false);
                didSilentSwap = false;
            }
            return true;
        }

        if (pullFromInventory.get()) {
            FindItemResult anyPearl = InvUtils.find(class_1802.field_8634);
            if (anyPearl.found()) {
                int toHotbar = pickHotbarSlot();
                apsDebug("Pulling pearl from inv slot " + anyPearl.slot() + " to hotbar " + toHotbar);
                InvUtils.move().from(anyPearl.slot()).toHotbar(toHotbar);
                InvUtils.swap(toHotbar, silentSwap.get());
                didMoveFromInv = true;
                movedFromSlot = anyPearl.slot();
                movedToHotbar = toHotbar;
                didSilentSwap = silentSwap.get();
                return true;
            }
        }

        apsDebug("No pearls available.");
        return false;
    }

    private void cleanupInventoryState() {
        cleanupInventoryState(didSilentSwap, didMoveFromInv, movedFromSlot, movedToHotbar);
    }

    private void cleanupInventoryState(boolean didSwap, boolean didMove, int fromSlot, int toHotbar) {
        if (mc.field_1724 == null || mc.field_1761 == null)
            return;

        if (didSwap) {
            try {
                InvUtils.swapBack();
                apsDebug("Reverted silent swap.");
            } catch (Throwable t) {
                apsDebug("Failed to revert silent swap: " + t.getMessage());
            }
        }

        if (didMove && toHotbar >= 0 && fromSlot >= 0) {
            class_1799 hotbarStack = safeGet(toHotbar);
            if (!hotbarStack.method_7960() && hotbarStack.method_7909() == class_1802.field_8634) {
                class_1799 original = safeGet(fromSlot);
                if (canAcceptPearls(original)) {
                    apsDebug("Restoring pearl to original slot " + fromSlot);
                    InvUtils.move().fromHotbar(toHotbar).to(fromSlot);
                } else if (silentSwap.get() || swapBackOnStricterServers.get()) {
                    int stackable = findMainInvPearlStackSlot();
                    if (stackable >= 0) {
                        apsDebug("Merging pearl to stack slot " + stackable);
                        InvUtils.move().fromHotbar(toHotbar).to(stackable);
                    } else {
                        int empty = findFirstEmptyMainSlot();
                        if (empty >= 0) {
                            apsDebug("Moving pearl to empty slot " + empty);
                            InvUtils.move().fromHotbar(toHotbar).to(empty);
                        } else {
                            apsDebug("Inventory full; leaving pearl in hotbar slot " + toHotbar);
                        }
                    }
                }
            } else {
                apsDebug("Hotbar slot " + toHotbar + " no longer holds pearl — nothing to restore.");
            }
        }

        usingOffhand = false;
        didSilentSwap = false;
        didMoveFromInv = false;
        movedFromSlot = -1;
        movedToHotbar = -1;
    }

    private class_1799 safeGet(int slot) {
        try {
            return mc.field_1724.method_31548().method_5438(slot);
        } catch (Throwable t) {
            return class_1799.field_8037;
        }
    }

    private boolean canAcceptPearls(class_1799 stack) {
        if (stack.method_7960())
            return true;
        if (stack.method_7909() != class_1802.field_8634)
            return false;
        return stack.method_7947() < Math.min(stack.method_7914(), 16);
    }

    private int findMainInvPearlStackSlot() {
        // Stay inside the main inventory: past MAIN_SIZE are the equipment
        // slots, and moving a pearl into the offhand would clear the totem.
        for (int i = 9; i < class_1661.field_30638; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (s.method_7909() == class_1802.field_8634 && s.method_7947() < Math.min(s.method_7914(), 16))
                return i;
        }
        return -1;
    }

    private int findFirstEmptyMainSlot() {
        for (int i = 9; i < class_1661.field_30638; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7960())
                return i;
        }
        return -1;
    }

    private int pickHotbarSlot() {
        if (mc != null && mc.field_1724 != null && preferEmptyHotbar.get()) {
            for (int i = 0; i < 9; i++) {
                if (mc.field_1724.method_31548().method_5438(i).method_7960())
                    return i;
            }
        }
        return class_3532.method_15340(tempHotbarSlot.get(), 0, 8);
    }

    private boolean pearlOnCooldown() {
        if (mc.field_1724 == null)
            return false;
        // Reflection by method name cannot work here: the names are remapped to
        // intermediary in a production jar, so every lookup missed and this
        // always reported "not on cooldown".
        return mc.field_1724.method_7357().method_7904(new class_1799(class_1802.field_8634));
    }

    private class_243 snapPointOnEdge(class_243 edge) {
        if (stasisWater == null)
            return edge;
        class_243 waterCenter = class_243.method_24953(stasisWater);
        class_243 fromWater = edge.method_1020(waterCenter);
        if (fromWater.method_1027() < 1e-6)
            return edge;
        return edge.method_1019(fromWater.method_1029().method_1021(0.14));
    }

    private boolean isHeadAboveSurface() {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null)
            return false;
        double eyeY = mc.field_1724.method_23320();
        class_2338 eyePos = class_2338.method_49637(mc.field_1724.method_23317(), eyeY, mc.field_1724.method_23321());
        if (mc.field_1687.method_8316(eyePos).method_15772() != class_3612.field_15910)
            return true;

        class_2338 feet = mc.field_1724.method_24515();
        double surfaceY = feet.method_10264() + 1.0;
        double headY = mc.field_1724.method_5829().field_1325;
        return headY > surfaceY + surfaceHeadClearance.get();
    }

    private void waterEscapeWatchdog() {
        if (!advancedWaterEscape.get() || standEdgePos == null || mc.field_1724 == null)
            return;

        class_243 p = mc.field_1724.method_73189();
        double dx = p.field_1352 - standEdgePos.field_1352, dz = p.field_1350 - standEdgePos.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);

        double speedSq = 0;
        if (lastPos != null) {
            double sx = p.field_1352 - lastPos.field_1352, sz = p.field_1350 - lastPos.field_1350;
            speedSq = sx * sx + sz * sz;
        }

        if (isInWater()) {
            mc.field_1724.method_36457(-exitPitchDeg.get().floatValue());
            faceTowardXZ(standEdgePos);

            pressForward(exitForwardTicks.get());
            pressSprint(exitSprintTicks.get());
            pressJump(exitJumpTicks.get());

            if (lastEdgeDist - dist < 0.02)
                noProgressTicks++;
            else
                noProgressTicks = 0;
            if (speedSq < 0.0004)
                stuckTicks++;
            else
                stuckTicks = 0;

            if (noProgressTicks >= 10 || stuckTicks >= 8) {
                escapeBoostTicks = Math.max(escapeBoostTicks, 6);
                noProgressTicks = 0;
                stuckTicks = 0;
            }
            if (escapeBoostTicks > 0) {
                escapeBoostTicks--;
                strongWaterEscapeBoost();
            }
        } else {
            noProgressTicks = stuckTicks = escapeBoostTicks = 0;
        }

        lastEdgeDist = dist;
    }

    private void strongWaterEscapeBoost() {
        if (mc == null || mc.field_1724 == null)
            return;
        class_243 target = (standEdgePos != null) ? standEdgePos : mc.field_1724.method_73189().method_1031(0, 0, 1);
        faceTowardXZ(target);
        try {
            mc.field_1724.method_6043();
        } catch (Throwable ignored) {
        }
        float yaw = mc.field_1724.method_36454();
        class_243 vel = mc.field_1724.method_18798();
        class_243 dir = new class_243(-Math.sin(Math.toRadians(yaw)), 0, Math.cos(Math.toRadians(yaw)));
        mc.field_1724.method_18799(vel.method_1019(dir.method_1021(0.20)).method_1031(0, 0.32, 0));
        mc.field_1724.method_5728(true);
    }

    private boolean isAtEdge() {
        if (standEdgePos == null || mc.field_1724 == null)
            return false;
        return isNearExact(standEdgePos, approachDistance.get() * 1.5);
    }

    private boolean isNearExact(class_243 target, double dist) {
        class_243 p = mc.field_1724.method_73189();
        double dx = p.field_1352 - target.field_1352, dz = p.field_1350 - target.field_1350;
        double distance = Math.sqrt(dx * dx + dz * dz);
        return distance <= dist;
    }

    private boolean isInWater() {
        return mc.field_1724 != null && mc.field_1724.method_5799();
    }

    private void calculateStepBackTarget() {
        if (stasisWater == null || mc.field_1724 == null || mc.field_1687 == null)
            return;

        class_243 playerPos = mc.field_1724.method_73189();
        class_243 waterCenter = class_243.method_24953(stasisWater);

        class_243 awayXZ = new class_243(playerPos.field_1352 - waterCenter.field_1352, 0, playerPos.field_1350 - waterCenter.field_1350);
        if (awayXZ.method_1027() < 1e-6)
            awayXZ = new class_243(0, 0, 1);
        awayXZ = awayXZ.method_1029();

        double[] radii = { 2.0, 2.2, 1.8, 2.4, 1.6 };
        double[] lateral = { 0.0, 0.4, -0.4, 0.7, -0.7 };

        class_243 bestVec = null;
        class_2338 bestBlock = null;

        outer: for (double r : radii) {
            for (double lat : lateral) {
                class_243 left = new class_243(-awayXZ.field_1350, 0, awayXZ.field_1352);
                class_243 probe = playerPos.method_1019(awayXZ.method_1021(r)).method_1019(left.method_1021(lat));

                class_2338 feet = class_2338.method_49637(probe.field_1352, Math.floor(playerPos.field_1351 + 0.001), probe.field_1350);
                class_2338 below = feet.method_10074();

                boolean solidBelow = !mc.field_1687.method_8320(below).method_26215()
                        && !mc.field_1687.method_8320(below).method_26220(mc.field_1687, below).method_1110()
                        && mc.field_1687.method_8316(below).method_15772() != class_3612.field_15910;

                boolean feetAir = mc.field_1687.method_8320(feet).method_26215()
                        || mc.field_1687.method_8320(feet).method_26220(mc.field_1687, feet).method_1110();

                class_2338 head = feet.method_10084();
                boolean headAir = mc.field_1687.method_8320(head).method_26215()
                        || mc.field_1687.method_8320(head).method_26220(mc.field_1687, head).method_1110();

                boolean feetIsWater = mc.field_1687.method_8316(feet).method_15772() == class_3612.field_15910;

                if (solidBelow && feetAir && headAir && !feetIsWater) {
                    bestBlock = feet.method_10062();
                    bestVec = new class_243(bestBlock.method_10263() + 0.5, bestBlock.method_10264() + 0.02, bestBlock.method_10260() + 0.5);
                    break outer;
                }
            }
        }

        if (bestVec == null) {
            double d = Math.min(Math.max(stepBackDistance.get(), 1.2), 2.4);
            bestVec = playerPos.method_1019(awayXZ.method_1021(d));
            bestVec = new class_243(bestVec.field_1352, playerPos.field_1351 + 0.02, bestVec.field_1350);
            bestBlock = class_2338.method_49638(bestVec);
        }

        stepBackTarget = bestVec;
        retreatGoalBlock = bestBlock;

        double flatDist = Math.sqrt(
                Math.pow(playerPos.field_1352 - stepBackTarget.field_1352, 2) +
                        Math.pow(playerPos.field_1350 - stepBackTarget.field_1350, 2));
        stepBackTicksRemaining = Math.max(stepBackTicks.get(), (int) Math.ceil(12 * flatDist));
    }

    private void stepBackFromStasis() {
        if (stepBackTarget == null || mc.field_1724 == null)
            return;

        releaseSneak();
        faceTowardXZ(stepBackTarget);

        pressForward(5);
        pressSprint(8);

        float yaw = mc.field_1724.method_36454();
        class_243 vel = mc.field_1724.method_18798();
        class_243 dir = new class_243(-Math.sin(Math.toRadians(yaw)), 0, Math.cos(Math.toRadians(yaw)));
        mc.field_1724.method_18799(vel.method_1019(dir.method_1021(0.12)));

        if (mc.field_1724.method_24828() && stepBackTicksRemaining == stepBackTicks.get() - 1) {
            try {
                mc.field_1724.method_6043();
            } catch (Throwable ignored) {
            }
        }
    }

    private boolean hasReachedStepBackTarget() {
        if (stepBackTarget == null || mc.field_1724 == null)
            return true;
        class_243 currentPos = mc.field_1724.method_73189();
        double dx = currentPos.field_1352 - stepBackTarget.field_1352;
        double dz = currentPos.field_1350 - stepBackTarget.field_1350;
        return (dx * dx + dz * dz) <= 0.49;
    }

    private boolean checkPearlIncreasedInStasis() {
        if (stasisWater == null || mc.field_1687 == null)
            return false;
        int currentCount = countPearlsInStasis();
        return currentCount > stasisPearlCountBefore;
    }

    private boolean detectAnyPearlInWater(class_2338 waterPos) {
        class_243 c = class_243.method_24953(waterPos);
        class_238 box = new class_238(c.field_1352 - 0.5, waterPos.method_10264(), c.field_1350 - 0.5, c.field_1352 + 0.5, waterPos.method_10264() + 1.0, c.field_1350 + 0.5);
        List<class_1684> pearls = mc.field_1687.method_8390(class_1684.class, box, class_1297::method_5805);
        return !pearls.isEmpty();
    }

    private int countPearlsInStasis() {
        if (stasisWater == null || mc.field_1687 == null)
            return 0;
        class_243 c = class_243.method_24953(stasisWater);
        class_238 box = new class_238(c.field_1352 - 0.5, stasisWater.method_10264(), c.field_1350 - 0.5, c.field_1352 + 0.5, stasisWater.method_10264() + 1.0, c.field_1350 + 0.5);
        List<class_1684> pearls = mc.field_1687.method_8390(class_1684.class, box, class_1297::method_5805);
        return pearls.size();
    }

    // Meteor's path manager wraps Baritone when it is installed and is a no-op
    // otherwise. Reaching into Baritone's own classes by reflection went
    // through its internal implementation types, so the calls threw and were
    // swallowed - pathing simply never happened, without a word.
    private void startPathTo(class_2338 targetBlock) {
        if (!useBaritone.get())
            return;
        PathManagers.get().moveTo(targetBlock, true);
    }

    private void stopPath() {
        if (!useBaritone.get())
            return;
        PathManagers.get().stop();
    }

    private void walkTowardExact(class_243 target) {
        if (mc.field_1724 == null || target == null)
            return;
        class_243 pos = mc.field_1724.method_73189();
        class_243 flatDelta = new class_243(target.field_1352 - pos.field_1352, 0, target.field_1350 - pos.field_1350);
        if (flatDelta.method_1027() < 1e-5)
            return;

        faceTowardXZ(target);
        pressForward(3);
        pressSprint(5);

        if (mc.field_1724.method_5799()) {
            class_243 vel = mc.field_1724.method_18798();
            class_243 fwd = new class_243(-Math.sin(Math.toRadians(mc.field_1724.method_36454())), 0,
                    Math.cos(Math.toRadians(mc.field_1724.method_36454())));
            mc.field_1724.method_18799(vel.method_1019(fwd.method_1021(0.04)).method_1031(0, 0.03, 0));
        }
    }

    private boolean findStasisAndEdge() {
        class_2338 base = mc.field_1724.method_24515();
        int r = searchRadius.get();

        class_2338 bestWater = null;
        class_2338 bestStand = null;
        class_243 bestEdge = null;
        double bestDist = Double.MAX_VALUE;

        class_2338.class_2339 m = new class_2338.class_2339();

        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -2; dy <= 3; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    m.method_10103(base.method_10263() + dx, base.method_10264() + dy, base.method_10260() + dz);
                    if (mc.field_1687.method_8316(m).method_15772() != class_3612.field_15910)
                        continue;

                    class_2338 td = m.method_10084();
                    if (!(mc.field_1687.method_8320(td).method_26204() instanceof class_2533))
                        continue;

                    class_243 waterCenter = class_243.method_24953(m);

                    for (class_2350 d : class_2350.class_2353.field_11062) {
                        class_2338 adj = m.method_10093(d);
                        if (!isSolidFloor(adj) || !isHeadroomOk(adj.method_10084()))
                            continue;

                        class_243 adjCenter = class_243.method_24953(adj);
                        class_243 toWater = new class_243(waterCenter.field_1352 - adjCenter.field_1352, 0, waterCenter.field_1350 - adjCenter.field_1350);
                        if (toWater.method_1027() < 1e-6)
                            continue;

                        class_243 edgePoint = adjCenter.method_1019(toWater.method_1029().method_1021(0.45));
                        double dist = mc.field_1724.method_73189().method_1025(edgePoint);
                        if (dist < bestDist) {
                            bestDist = dist;
                            bestWater = m.method_10062();
                            bestStand = adj.method_10062();
                            bestEdge = edgePoint;
                        }
                    }
                }
            }
        }

        stasisWater = bestWater;
        standBlock = bestStand;
        standEdgePos = bestEdge;
        return stasisWater != null && standBlock != null && standEdgePos != null;
    }

    private boolean isSolidFloor(class_2338 pos) {
        return !mc.field_1687.method_8320(pos).method_26215()
                && !mc.field_1687.method_8320(pos).method_26220(mc.field_1687, pos).method_1110()
                && mc.field_1687.method_8316(pos).method_15772() != class_3612.field_15910;
    }

    private boolean isHeadroomOk(class_2338 posAboveFeet) {
        class_2680 s = mc.field_1687.method_8320(posAboveFeet);
        return s.method_26215() || s.method_26220(mc.field_1687, posAboveFeet).method_1110();
    }

    private void faceTowardXZ(class_243 target) {
        if (mc.field_1724 == null || target == null)
            return;
        class_243 playerPos = mc.field_1724.method_73189();
        class_243 flatDelta = new class_243(target.field_1352 - playerPos.field_1352, 0, target.field_1350 - playerPos.field_1350);
        if (flatDelta.method_1027() < 1e-6)
            return;

        float yaw = (float) (class_3532.method_15338(Math.toDegrees(Math.atan2(flatDelta.field_1350, flatDelta.field_1352)) - 90.0));
        mc.field_1724.method_36456(yaw);
        mc.method_1562().method_52787(new class_2828.class_2831(
                yaw, mc.field_1724.method_36455(), mc.field_1724.method_24828(), false));
    }

    private void pressSneak() {
        if (mc.field_1690 != null) mc.field_1690.field_1832.method_23481(true);
    }

    private void releaseSneak() {
        if (mc.field_1690 != null) mc.field_1690.field_1832.method_23481(false);
    }

    private void pressForward(int ticks) {
        holdForward = Math.max(holdForward, ticks);
    }

    private void pressSprint(int ticks) {
        holdSprint = Math.max(holdSprint, ticks);
    }

    private void pressJump(int ticks) {
        holdJump = Math.max(holdJump, ticks);
    }

    private void maintainMovementKeys() {
        if (mc.field_1690 == null) return;
        mc.field_1690.field_1894.method_23481(holdForward-- > 0);
        mc.field_1690.field_1867.method_23481(holdSprint-- > 0);
        mc.field_1690.field_1903.method_23481(holdJump-- > 0);
    }

    private void releaseAllMoveKeys() {
        holdForward = holdSprint = holdJump = 0;
        if (mc.field_1690 == null) return;
        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1867.method_23481(false);
        mc.field_1690.field_1903.method_23481(false);
    }

    private void infoOnce(String message) {
        if (debugChat.get())
            apsDebug(message);
    }

    private void logState() {
        if (debugChat.get() && lastLoggedState != assistState) {
            apsDebug("State: " + assistState);
            lastLoggedState = assistState;
        }
    }

    private int parseKey(String key) {
        if (key == null || key.isBlank())
            return GLFW.GLFW_KEY_UNKNOWN;

        // Accept what people actually type: "left shift", " g ", "F4".
        String name = key.trim().replace(' ', '_').replace('-', '_').toUpperCase(Locale.ROOT);
        try {
            return GLFW.class.getField("GLFW_KEY_" + name).getInt(null);
        } catch (ReflectiveOperationException ignored) {
            warning("Unknown key '%s' - expected a GLFW key name such as G, F4 or LEFT_SHIFT.", key);
            return GLFW.GLFW_KEY_UNKNOWN;
        }
    }

    private int countTotems() {
        if (mc.field_1724 == null)
            return 0;
        int count = 0;
        // Stop at MAIN_SIZE: getInventory().size() also covers the equipment
        // slots, and the offhand among them would be counted twice.
        for (int i = 0; i < class_1661.field_30638; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8288))
                count += mc.field_1724.method_31548().method_5438(i).method_7947();
        }
        if (mc.field_1724.method_6079().method_31574(class_1802.field_8288))
            count += mc.field_1724.method_6079().method_7947();
        return count;
    }

    // --------- Stainless tag helpers for this module ---------
    private void apsDebug(String msg) {
        // debug color (AQUA) via StainlessModule
        sendDebugMsg("[APS] " + msg);
    }

    private void apsProxDebug(String msg) {
        sendDebugMsg("[APS] [PROX] " + msg);
    }

    private void apsInfo(String msg) {
        // normal info (GRAY) via StainlessModule
        sendInfoMsg("[APS] " + msg);
    }

    // --- Helpers from StainlessModule ported ---
    private void sendInfoMsg(String text) {
        sendColoredMsg(text, class_124.field_1080, (name + "-info").hashCode());
    }

    private void sendDebugMsg(String text) {
        sendColoredMsg(text, class_124.field_1075, (name + "-debug").hashCode());
    }

    private void sendColoredMsg(String text, class_124 color, int id) {
        if (!shouldChat())
            return;
        ChatUtils.forceNextPrefixClass(getClass());
        class_2561 msg = class_2561.method_43473()
                .method_10852(class_2561.method_43470("[APS] ").method_27692(class_124.field_1062))
                .method_10852(class_2561.method_43470(text).method_27692(color));
        sendMessage(msg, id);
    }

    private boolean shouldChat() {
        return mc != null && mc.field_1687 != null && mc.field_1705 != null && mc.field_1705.method_1743() != null;
    }

    private void sendMessage(class_2561 text, int id) {
        ((IChatHud) mc.field_1705.method_1743()).meteor$add(text, id);
    }
}
