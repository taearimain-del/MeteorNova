package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.systems.friends.Friend;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import meteordevelopment.meteorclient.events.meteor.MouseClickEvent;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import org.lwjgl.glfw.GLFW;

public class MiddleClickFriend extends Module {

    public MiddleClickFriend() {
        super(Addon.CATEGORY, "middle-click-friend", "Add/Remove friends by middle clicking them.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("MiddleClickFriend", true);
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("MiddleClickFriend", false);
    }

    @EventHandler
    private void onMouseButton(MouseClickEvent event) {
        if (event.action == KeyAction.Press && event.button() == GLFW.GLFW_MOUSE_BUTTON_MIDDLE
                && mc.field_1755 == null) {
            class_1297 target = mc.field_1692;

            if (target instanceof class_1657 player) {
                String name = player.method_5477().getString();

                if (Friends.get().isFriend(player)) {
                    Friends.get().remove(Friends.get().get(player));
                    ChatUtils.info(class_124.field_1061 + "Removed " + name + " from friends.");
                } else {
                    Friends.get().add(new Friend(player));
                    ChatUtils.info(class_124.field_1060 + "Added " + name + " to friends.");
                }
            }
        }
    }
}
