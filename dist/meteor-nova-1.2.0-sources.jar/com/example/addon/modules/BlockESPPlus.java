package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class BlockESPPlus extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    // Block Group 1
    private final Setting<List<class_2248>> blocks1 = sgGeneral.add(new BlockListSetting.Builder()
            .name("blocks-1")
            .description("Blocks to render (Red).")
            .build());

    private final Setting<SettingColor> color1 = sgGeneral.add(new ColorSetting.Builder()
            .name("color-1")
            .defaultValue(new SettingColor(255, 0, 0, 100))
            .build());

    // Block Group 2
    private final Setting<List<class_2248>> blocks2 = sgGeneral.add(new BlockListSetting.Builder()
            .name("blocks-2")
            .description("Blocks to render (Blue).")
            .build());

    private final Setting<SettingColor> color2 = sgGeneral.add(new ColorSetting.Builder()
            .name("color-2")
            .defaultValue(new SettingColor(0, 0, 255, 100))
            .build());

    // Entity Group 1
    private final Setting<Set<class_1299<?>>> entities1 = sgGeneral.add(new EntityTypeListSetting.Builder()
            .name("entities-1")
            .description("Entities to render (Group 1).")
            .build());

    private final Setting<SettingColor> entColor1 = sgGeneral.add(new ColorSetting.Builder()
            .name("ent-color-1")
            .defaultValue(new SettingColor(0, 255, 0, 100))
            .build());

    // Settings
    private final Setting<Integer> range = sgGeneral.add(new IntSetting.Builder()
            .name("block-scan-range")
            .description("Scan range for blocks (heavy).")
            .defaultValue(8)
            .sliderMax(16)
            .build());

    // Scanning the cube every frame is tens of thousands of block lookups a
    // frame; scan on a tick instead and let rendering just walk the results.
    private static final int SCAN_INTERVAL = 10;
    private int scanTicks = 0;
    private final List<class_2338> found1 = new ArrayList<>();
    private final List<class_2338> found2 = new ArrayList<>();
    private final List<class_1297> foundEntities = new ArrayList<>();

    public BlockESPPlus() {
        super(Addon.CATEGORY, "block-esp-plus", "ESP for Blocks and Entities with custom colors.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("BlockESPPlus", true);
        clearFound();
        scanTicks = 0;
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("BlockESPPlus", false);
        clearFound();
    }

    private void clearFound() {
        found1.clear();
        found2.clear();
        foundEntities.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            clearFound();
            return;
        }

        if (--scanTicks > 0)
            return;
        scanTicks = SCAN_INTERVAL;

        clearFound();

        int r = range.get();
        class_2338 center = mc.field_1724.method_24515();

        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    class_2338 pos = center.method_10069(x, y, z);
                    class_2248 block = mc.field_1687.method_8320(pos).method_26204();

                    if (blocks1.get().contains(block)) {
                        found1.add(pos);
                    } else if (blocks2.get().contains(block)) {
                        found2.add(pos);
                    }
                }
            }
        }

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entities1.get().contains(entity.method_5864()))
                foundEntities.add(entity);
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        for (class_2338 pos : found1)
            event.renderer.box(pos, color1.get(), color1.get(), ShapeMode.Lines, 0);

        for (class_2338 pos : found2)
            event.renderer.box(pos, color2.get(), color2.get(), ShapeMode.Lines, 0);

        // Boxes come from the entity so they follow it between scans.
        for (class_1297 entity : foundEntities) {
            if (!entity.method_31481())
                event.renderer.box(entity.method_5829(), entColor1.get(), entColor1.get(), ShapeMode.Lines, 0);
        }
    }
}
