package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import meteordevelopment.meteorclient.events.world.TickEvent;
import java.util.List;

public class InventoryCleaner extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<class_1792>> items = sgGeneral.add(new ItemListSetting.Builder()
            .name("items")
            .description("Items to throw away.")
            .defaultValue(class_1802.field_8831, class_1802.field_20412, class_1802.field_20407, class_1802.field_20401, class_1802.field_20394)
            .build());

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("Delay in ticks between throwing items.")
            .defaultValue(2)
            .min(0)
            .build());

    private int timer = 0;

    public InventoryCleaner() {
        super(Addon.CATEGORY, "inventory-cleaner", "Automatically throws away specified items.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("InventoryCleaner", true);
        timer = 0;
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("InventoryCleaner", false);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (timer > 0) {
            timer--;
            return;
        }

        // インベントリのメインスロット（9〜35）とホットバー（0〜8）を走査
        // ※ InvUtilsの実装依存ですが、通常ループで回します

        for (int i = 9; i < 36; i++) { // メインインベントリ優先
            if (checkAndDrop(i))
                return;
        }
        for (int i = 0; i < 9; i++) { // ホットバー
            if (checkAndDrop(i))
                return;
        }
    }

    private boolean checkAndDrop(int slot) {
        if (mc.field_1724 == null)
            return false;

        class_1792 item = mc.field_1724.method_31548().method_5438(slot).method_7909();
        if (item != class_1802.field_8162 && items.get().contains(item)) {
            InvUtils.drop().slot(slot);
            timer = delay.get();
            return true;
        }
        return false;
    }
}
