package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import com.example.addon.utils.NovaKeybindUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2292;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import org.lwjgl.glfw.GLFW;

public class ConcreteWeb extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("range")
            .description("Range to detect target.")
            .defaultValue(5.0)
            .build());

    private final Setting<Keybind> webAuraKey = sgGeneral.add(new KeybindSetting.Builder()
            .name("web-aura-key")
            .description("Key to toggle external Web Aura (Mio Client).")
            .defaultValue(Keybind.fromKey(GLFW.GLFW_KEY_B))
            .build());

    private final Setting<Boolean> debug = sgGeneral.add(new BoolSetting.Builder()
            .name("debug")
            .description("Send chat messages when toggling.")
            .defaultValue(true)
            .build());

    private boolean isAuraActive = false;
    private int toggleTimer = 0;
    private int activeTimer = 0;

    public ConcreteWeb() {
        super(Addon.CATEGORY, "concrete-web", "Toggles external Web Aura when target is lifted by concrete.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("ConcreteWeb", true);
        isAuraActive = false;
        toggleTimer = 0;
        activeTimer = 0;
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("ConcreteWeb", false);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1687 == null || mc.field_1724 == null)
            return;

        if (toggleTimer > 0)
            toggleTimer--;
        if (isAuraActive)
            activeTimer++;

        class_1657 target = findNearestTarget();

        // Safety: Turn off if no target found while active
        if (target == null) {
            if (isAuraActive && toggleTimer == 0) {
                toggleWebAura(false);
            }
            return;
        }

        boolean onPowder = isConcretePowder(target.method_24515().method_10074()) || isConcretePowder(target.method_24515());
        boolean inWeb = isInWeb(target);

        if (!isAuraActive) {
            // Activate if target is lifted by powder
            if (onPowder && toggleTimer == 0) {
                toggleWebAura(true);
            }
        } else {
            // Deactivate if target is NOT in web (escaped)
            // Wait at least 10 ticks after activation to allow web to spawn
            if (activeTimer > 10 && !inWeb && toggleTimer == 0) {
                toggleWebAura(false);
            }
        }
    }

    private void toggleWebAura(boolean state) {
        isAuraActive = state;
        toggleTimer = 10; // Prevent spam toggling
        if (state)
            activeTimer = 0;

        pressKey();

        if (debug.get()) {
            NovaChatUtils.sendInfoMsg("ConcreteWeb", state ? "Toggled Web Aura >> ON" : "Toggled Web Aura >> OFF");
        }
    }

    private void pressKey() {
        NovaKeybindUtils.pressKey(webAuraKey.get(), 1);
    }

    private class_1657 findNearestTarget() {
        class_1657 best = null;
        double bestDist = range.get() * range.get();

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724 || Friends.get().isFriend(p))
                continue;
            double dist = mc.field_1724.method_5858(p);
            if (dist <= bestDist) {
                best = p;
                bestDist = dist;
            }
        }
        return best;
    }

    private boolean isConcretePowder(class_2338 pos) {
        return mc.field_1687.method_8320(pos).method_26204() instanceof class_2292;
    }

    private boolean isInWeb(class_1657 player) {
        class_238 box = player.method_5829();
        class_2338 min = class_2338.method_49637(box.field_1323, box.field_1322, box.field_1321);
        class_2338 max = class_2338.method_49637(box.field_1320, box.field_1325, box.field_1324);

        for (int x = min.method_10263(); x <= max.method_10263(); x++) {
            for (int y = min.method_10264(); y <= max.method_10264(); y++) {
                for (int z = min.method_10260(); z <= max.method_10260(); z++) {
                    class_2338 pos = new class_2338(x, y, z);
                    if (mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10343) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
