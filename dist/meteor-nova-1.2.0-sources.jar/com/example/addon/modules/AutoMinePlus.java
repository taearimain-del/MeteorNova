package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.meteorclient.renderer.Renderer3D;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_9334;

public class AutoMinePlus extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final SettingGroup sgRender = settings.createGroup("Render");

    // Targeting & ranges
    private final Setting<Double> targetRange = sgGeneral.add(new DoubleSetting.Builder()
            .name("target-range").description("Range to target players.")
            .defaultValue(5.5).min(1).sliderMax(6).build());

    private final Setting<Double> breakRange = sgGeneral.add(new DoubleSetting.Builder()
            .name("break-range").description("Maximum block break range.")
            .defaultValue(4.5).min(1).sliderMax(6).build());

    // Bedrock options
    private final Setting<Boolean> mineBedrock = sgGeneral.add(new BoolSetting.Builder()
            .name("mine-bedrock").description("Allows mining bedrock blocks around the target.")
            .defaultValue(false).build());

    private final Setting<Boolean> bedrockOnly = sgGeneral.add(new BoolSetting.Builder()
            .name("bedrock-only").description("Only break bedrock. Ignore all other blocks.")
            .defaultValue(false).visible(mineBedrock::get).build());

    private final Setting<Boolean> prioritizePlayerBedrock = sgGeneral.add(new BoolSetting.Builder()
            .name("prioritize-target-standing-bedrock")
            .description("Prioritize mining the bedrock the target is standing in over surrounding blocks.")
            .defaultValue(true).visible(mineBedrock::get).build());

    // Clear your own upper hitbox bedrock
    private final Setting<Boolean> clearUpperBedrock = sgGeneral.add(new BoolSetting.Builder()
            .name("clear-upper-bedrock")
            .description("If phased, automatically mine the bedrock at your upper hitbox to free AutoMine/AutoCrystal.")
            .defaultValue(true).build());

    // Filters
    private final Setting<Boolean> ignoreFriends = sgGeneral.add(new BoolSetting.Builder()
            .name("ignore-friends").description("Don't target players on your friends list.")
            .defaultValue(true).build());

    private final Setting<Boolean> ignoreNaked = sgGeneral.add(new BoolSetting.Builder()
            .name("ignore-naked").description("Don't target players with no armor equipped.")
            .defaultValue(true).build());

    // Placement/support
    private final Setting<Boolean> support = sgGeneral.add(new BoolSetting.Builder()
            .name("support").description("Places support block under break target if missing.")
            .defaultValue(true).build());

    private final Setting<Double> placeRange = sgGeneral.add(new DoubleSetting.Builder()
            .name("place-range").description("How far to place support blocks.")
            .defaultValue(4.5).min(1).sliderMax(6).visible(support::get).build());

    // QoL
    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate").description("Rotate to block before mining.")
            .defaultValue(true).build());

    private final Setting<Boolean> pauseWhileEating = sgGeneral.add(new BoolSetting.Builder()
            .name("pause-while-eating").description("Temporarily pauses AutoMinePlus while you're eating food.")
            .defaultValue(true).build());

    private final Setting<Boolean> chatInfo = sgGeneral.add(new BoolSetting.Builder()
            .name("chat-info").description("Sends debug info in chat.")
            .defaultValue(true).build());

    private final Setting<Integer> chatDelay = sgGeneral.add(new IntSetting.Builder()
            .name("chat-delay").description("Minimum ticks between messages (2s min enforced).")
            .defaultValue(40).min(0).sliderMax(200).build());

    // ---------------- RENDER (BlackOut-style gradient, synced) ----------------
    private final Setting<Double> animationExp = sgRender.add(new DoubleSetting.Builder()
            .name("animation-exp").description("Ease exponent. 3–4 looks nice.")
            .defaultValue(3).range(0, 10).sliderRange(0, 10).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
            .name("Shape Mode").description("Which parts of render should be rendered.")
            .defaultValue(ShapeMode.Both).build());

    private final Setting<SettingColor> lineStartColor = sgRender.add(new ColorSetting.Builder()
            .name("Line Start Color").description("Start of line gradient.")
            .defaultValue(new SettingColor(255, 0, 0, 0)).build());
    private final Setting<SettingColor> lineEndColor = sgRender.add(new ColorSetting.Builder()
            .name("Line End Color").description("End of line gradient.")
            .defaultValue(new SettingColor(255, 0, 0, 255)).build());
    private final Setting<SettingColor> startColor = sgRender.add(new ColorSetting.Builder()
            .name("Side Start Color").description("Start of side gradient.")
            .defaultValue(new SettingColor(255, 0, 0, 0)).build());
    private final Setting<SettingColor> endColor = sgRender.add(new ColorSetting.Builder()
            .name("Side End Color").description("End of side gradient.")
            .defaultValue(new SettingColor(255, 0, 0, 50)).build());

    // Bedrock-only progress estimate for render when vanilla delta==0
    private final Setting<Integer> bedrockProgressEstimateTicks = sgRender.add(new IntSetting.Builder()
            .name("bedrock-progress-estimate-ticks")
            .description("When bedrock has 0 vanilla delta, assume it breaks after this many ticks (render only).")
            .defaultValue(40).min(1).sliderMax(200).build());

    // ---------------- State ----------------
    private class_1657 target;
    private class_2338 targetPos;

    // Chat throttle
    private int chatCooldown = 0;
    private String pendingChat = null;
    private boolean wasEating = false;

    // Mining progress sync
    private double breakProgress = 0.0; // 0..1 visual progress
    private class_2338 lastBreakPos = null;
    private boolean minedThisTick = false;

    // Just to keep the two-pass alpha feel from your reference
    private long lastTimeMs = 0;
    private double renderPulse = 1;
    private int renderDir = 1;

    public AutoMinePlus() {
        super(Addon.CATEGORY, "auto-mine-plus", "AutoMine with bedrock utilities.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("AutoMinePlus", true);
        target = null;
        targetPos = null;
        chatCooldown = 0;
        pendingChat = null;
        wasEating = false;

        breakProgress = 0;
        lastBreakPos = null;
        minedThisTick = false;

        lastTimeMs = System.currentTimeMillis();
        renderPulse = 1;
        renderDir = 1;
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("AutoMinePlus", false);
    }

    // ---- CHAT THROTTLE (2s min) ----
    private void chat(String msg) {
        // Chat feedback disabled per user request
    }
    // --------------------------------

    private boolean shouldAllowRotation() {
        class_2338 playerPos = mc.field_1724.method_24515();
        class_2248 blockAtFeet = mc.field_1687.method_8320(playerPos).method_26204();
        class_2248 blockAboveHead = mc.field_1687.method_8320(playerPos.method_10086(1)).method_26204();
        return !(blockAtFeet == class_2246.field_10124 && blockAboveHead != class_2246.field_10124);
    }

    @EventHandler
    public void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        minedThisTick = false; // reset per tick

        // chat cooldown tick
        if (chatCooldown > 0) {
            chatCooldown--;
            if (chatCooldown == 0 && pendingChat != null) {
                int cooldownTicks = Math.max(40, chatDelay.get());
                NovaChatUtils.sendInfoMsg("AutoMinePlus", pendingChat);
                pendingChat = null;
                chatCooldown = cooldownTicks;
            }
        }

        // pause while eating
        if (pauseWhileEating.get() && mc.field_1724 != null) {
            boolean eatingNow = mc.field_1724.method_6115() && isFood(mc.field_1724.method_6030());
            if (eatingNow) {
                if (!wasEating) {
                    chat("Paused: eating.");
                    wasEating = true;
                }
                // no mining; don't advance progress
                updateBreakProgress();
                return;
            } else if (wasEating) {
                chat("Resuming after eating.");
                wasEating = false;
            }
        }

        // 1) Clear your own upper hitbox bedrock first
        if (clearUpperBedrock.get()) {
            class_2338 headPos = mc.field_1724.method_24515().method_10086(1);
            if (mc.field_1687.method_8320(headPos).method_26204() == class_2246.field_9987) {
                targetPos = headPos;

                if (support.get() && mc.field_1687.method_8320(targetPos.method_10074()).method_26215()) {
                    BlockUtils.place(targetPos.method_10074(), InvUtils.findInHotbar(class_1802.field_8281), rotate.get(), 0, true);
                }

                if (rotate.get())
                    Rotations.rotate(Rotations.getYaw(targetPos), Rotations.getPitch(targetPos));

                mc.field_1761.method_2902(targetPos, class_2350.field_11036);
                mc.field_1724.method_6104(class_1268.field_5808);
                minedThisTick = true;

                chat("Clearing upper-hitbox bedrock.");
                updateBreakProgress();
                return;
            }
        }

        // 2) Acquire/refresh target
        target = null;
        double closestDistance = targetRange.get() * targetRange.get();

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724 || player.method_68878() || player.method_7325())
                continue;
            if (ignoreFriends.get() && Friends.get().isFriend(player))
                continue;
            if (ignoreNaked.get() && isNaked(player))
                continue;

            double distance = player.method_5858(mc.field_1724);
            if (distance <= closestDistance) {
                closestDistance = distance;
                target = player;
            }
        }

        if (target == null) {
            targetPos = null;
            updateBreakProgress();
            return;
        }

        // 3) Prefer bedrock in the target's lower hitbox
        boolean handledStandingBedrock = false;
        if (mineBedrock.get() && prioritizePlayerBedrock.get()) {
            class_2338 lowerHitboxPos = target.method_24515();
            if (mc.field_1687.method_8320(lowerHitboxPos).method_26204() == class_2246.field_9987
                    && PlayerUtils.squaredDistanceTo(lowerHitboxPos) <= breakRange.get() * breakRange.get()) {
                targetPos = lowerHitboxPos;
                handledStandingBedrock = true;
                chat("Breaking bedrock in target's lower hitbox.");
            }
        }

        // 4) Otherwise pick a city block (respect bedrock-only)
        if (!handledStandingBedrock) {
            targetPos = findCityBlock(target);
            if (targetPos == null) {
                if (bedrockOnly.get())
                    chat("Bedrock-only: no bedrock found near target.");
                updateBreakProgress();
                return;
            }
            class_2248 blk = mc.field_1687.method_8320(targetPos).method_26204();
            chat(blk == class_2246.field_9987 ? "Breaking surrounding bedrock."
                    : "Breaking surrounding block: " + blk.method_9518().getString());
        }

        if (PlayerUtils.squaredDistanceTo(targetPos) > breakRange.get() * breakRange.get()) {
            updateBreakProgress();
            return;
        }

        // Support placement
        if (support.get()
                && mc.field_1687.method_8320(targetPos.method_10074()).method_26215()
                && PlayerUtils.squaredDistanceTo(targetPos.method_10074()) <= placeRange.get() * placeRange.get()) {
            BlockUtils.place(targetPos.method_10074(), InvUtils.findInHotbar(class_1802.field_8281), rotate.get(), 0, true);
        }

        boolean allowActions = shouldAllowRotation();
        if (targetPos.equals(mc.field_1724.method_24515().method_10086(1)))
            allowActions = true;

        if (rotate.get() && allowActions) {
            Rotations.rotate(Rotations.getYaw(targetPos), Rotations.getPitch(targetPos));
        }

        if (allowActions) {
            mc.field_1761.method_2902(targetPos, class_2350.field_11036);
            mc.field_1724.method_6104(class_1268.field_5808);
            minedThisTick = true;
        }

        updateBreakProgress();
    }

    /**
     * Progress sync: advance visual progress when we actually mine this tick.
     * Uses vanilla delta; falls back to estimate for bedrock if needed.
     */
    private void updateBreakProgress() {
        if (targetPos == null) {
            breakProgress = 0;
            lastBreakPos = null;
            return;
        }
        if (lastBreakPos == null || !lastBreakPos.equals(targetPos)) {
            breakProgress = 0;
            lastBreakPos = targetPos.method_10062();
        }
        if (!minedThisTick)
            return;

        class_2680 state = mc.field_1687.method_8320(targetPos);
        float d = state.method_26165(mc.field_1724, mc.field_1687, targetPos);

        if (d <= 0f && state.method_26204() == class_2246.field_9987) {
            // render-only estimate so the bar moves when your server lets bedrock break
            d = 1f / Math.max(1, bedrockProgressEstimateTicks.get());
        }

        // For non-bedrock unbreakable or weird states, if delta==0, don't move.
        breakProgress = class_3532.method_15350(breakProgress + d, 0.0, 1.0);

        // Reset after "complete" so next block animates from 0
        if (breakProgress >= 1.0) {
            breakProgress = 0.0;
            lastBreakPos = null;
        }
    }

    /**
     * Bedrock priority; fall back to solids unless bedrock-only is on.
     */
    private class_2338 findCityBlock(class_1657 target) {
        class_2338 pos = target.method_24515();

        // Pass 1: bedrock
        if (mineBedrock.get()) {
            for (class_2350 dir : class_2350.class_2353.field_11062) {
                class_2338 off = pos.method_10093(dir);
                if (PlayerUtils.squaredDistanceTo(off) > breakRange.get() * breakRange.get())
                    continue;
                if (mc.field_1687.method_8320(off).method_26204() == class_2246.field_9987)
                    return off;
            }
        }

        if (bedrockOnly.get())
            return null;

        // Pass 2: any solid (non-air, non-liquid, not bedrock)
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2338 off = pos.method_10093(dir);
            if (PlayerUtils.squaredDistanceTo(off) > breakRange.get() * breakRange.get())
                continue;
            if (!mc.field_1687.method_8316(off).method_15769())
                continue;
            class_2248 b = mc.field_1687.method_8320(off).method_26204();
            if (b == class_2246.field_10124 || b == class_2246.field_9987)
                continue;
            return off;
        }
        return null;
    }

    private boolean isNaked(class_1657 p) {
        return p.method_6118(class_1304.field_6169).method_7960()
                && p.method_6118(class_1304.field_6174).method_7960()
                && p.method_6118(class_1304.field_6172).method_7960()
                && p.method_6118(class_1304.field_6166).method_7960();
    }

    private boolean isFood(class_1799 stack) {
        return stack != null && !stack.method_7960() && stack.method_58694(class_9334.field_50075) != null;
    }

    // ----------gradient render----------
    private Color getColor(SettingColor start, SettingColor end, double progress, double alphaMulti) {
        return new Color(
                lerp(start.r, end.r, progress, 1),
                lerp(start.g, end.g, progress, 1),
                lerp(start.b, end.b, progress, 1),
                lerp(start.a, end.a, progress, alphaMulti));
    }

    private int lerp(double start, double end, double d, double multi) {
        return (int) Math.round((start + (end - start) * d) * multi);
    }

    private class_238 getRenderBox(double progress) {
        double cx = targetPos.method_10263() + 0.5;
        double cy = targetPos.method_10264() + 0.5;
        double cz = targetPos.method_10260() + 0.5;
        double r = class_3532.method_15350(progress, 0.0, 0.5);
        return new class_238(cx - r, cy - r, cz - r, cx + r, cy + r, cz + r);
    }

    @EventHandler
    public void onRender(Render3DEvent event) {
        if (targetPos == null)
            return;

        // keep a gentle alpha pulse like the reference's two-pass look
        long now = System.currentTimeMillis();
        double dt = (now - lastTimeMs) / 1000d;
        lastTimeMs = now;
        renderPulse += dt * 2 * renderDir;
        if (renderPulse >= 2) {
            renderPulse = 2;
            renderDir = -1;
        }
        if (renderPulse <= -2) {
            renderPulse = -2;
            renderDir = 1;
        }

        // progress based on actual mining delta (synced)
        double base = class_3532.method_15350(breakProgress, 0.0, 1.0);
        // match reference easing: p = 1 - (1 - base)^exp
        double p = 1.0 - Math.pow(1.0 - base, animationExp.get());

        Renderer3D r = event.renderer;

        // Pass 1
        r.box(
                getRenderBox(p / 2.0),
                getColor(startColor.get(), endColor.get(), p, class_3532.method_15350(renderPulse, 0, 1)),
                getColor(lineStartColor.get(), lineEndColor.get(), p, class_3532.method_15350(renderPulse, 0, 1)),
                shapeMode.get(), 0);

        // Pass 2 (inverted alpha)
        r.box(
                getRenderBox(p / 2.0),
                getColor(startColor.get(), endColor.get(), p, class_3532.method_15350(-renderPulse, 0, 1)),
                getColor(lineStartColor.get(), lineEndColor.get(), p, class_3532.method_15350(-renderPulse, 0, 1)),
                shapeMode.get(), 0);
    }
}
