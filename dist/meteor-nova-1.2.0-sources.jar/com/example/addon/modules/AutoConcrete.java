package com.example.addon.modules;

import com.example.addon.Addon;
import com.example.addon.utils.NovaChatUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1540;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2292;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_8810;
import net.minecraft.class_9334;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class AutoConcrete extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("range").defaultValue(4).min(0).sliderMax(6).build());

    private final Setting<Integer> concreteCount = sgGeneral.add(new IntSetting.Builder()
            .name("concrete-count").description("How many falling blocks to drop at once.")
            .defaultValue(1).min(1).max(3).sliderMax(3).build());

    private final Setting<Integer> pillarDelay = sgGeneral.add(new IntSetting.Builder()
            .name("pillar-delay").defaultValue(30).min(0).sliderMax(100).build());

    private final Setting<Integer> concreteDelay = sgGeneral.add(new IntSetting.Builder()
            .name("drop-delay").defaultValue(50).min(0).sliderMax(100).build());

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate").defaultValue(true).build());

    private final Setting<Boolean> detectCrystals = sgGeneral.add(new BoolSetting.Builder()
            .name("detect-crystals").defaultValue(true).build());

    private final Setting<Boolean> airPlace = sgGeneral.add(new BoolSetting.Builder()
            .name("air-place").defaultValue(false).build());

    private final Setting<Boolean> placeSupport = sgGeneral.add(new BoolSetting.Builder()
            .name("place-support").defaultValue(true).build());

    private final Setting<Boolean> disableOnUse = sgGeneral.add(new BoolSetting.Builder()
            .name("disable-on-use").description("Turns off the module after placing falling blocks.")
            .defaultValue(false).build());

    private final Setting<Boolean> onlyInHole = sgGeneral.add(new BoolSetting.Builder()
            .name("only-in-hole")
            .description("Only place blocks if the target has blocks on all 4 sides.")
            .defaultValue(false)
            .build());

    private final Setting<Boolean> smartMode = sgGeneral.add(new BoolSetting.Builder()
            .name("smart-mode")
            .description("Don't place if the target already has obstacles (Web/Button/etc) at feet.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> pauseWhileEating = sgGeneral.add(new BoolSetting.Builder()
            .name("pause-while-eating")
            .description("Temporarily pauses AutoConcrete while you're eating food.")
            .defaultValue(true)
            .build());

    private final Setting<Integer> fishTrapDelay = sgGeneral.add(new IntSetting.Builder()
            .name("fish-trap-delay")
            .description("Delay (ticks) before placing trap after powder to let it fall.")
            .defaultValue(15)
            .min(0)
            .build());

    private final Setting<Boolean> smartPlace = sgGeneral.add(new BoolSetting.Builder()
            .name("smart-place")
            .description("Prevents placing traps if concrete powder is missing.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> fishTrap = sgGeneral.add(new BoolSetting.Builder()
            .name("fish-trap")
            .description("Places a block at Y+4 to force swim mode (Fish Trap).")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> fishTrapAirPlace = sgGeneral.add(new BoolSetting.Builder()
            .name("fish-trap-air-place")
            .description("Allows placing the fish trap block in the air (use correct server rotation settings).")
            .defaultValue(true)
            .build());

    private class_1657 target;
    private class_2338 basePos;
    private class_2338[] concretePositions;
    private class_2338 lastTargetPos;
    private class_2350 placedDirection;
    private int currentPillarHeight;
    private int cooldown = 0;
    private boolean wasEating = false;

    private final Set<UUID> placedTargets = new HashSet<>();
    // Temporary set to track positions placed in this cycle to avoid spam due to
    // falling entity delay
    private final Set<class_2338> temporaryPlacedPositions = new HashSet<>();
    private final Map<class_2338, Integer> trapQueue = new HashMap<>();

    public AutoConcrete() {
        super(Addon.CATEGORY, "auto-concrete", "Drops falling blocks above enemies' heads.");
    }

    @Override
    public void onActivate() {
        NovaChatUtils.sendToggleMsg("AutoConcrete", true);
        reset();
        placedTargets.clear();
        temporaryPlacedPositions.clear();
        trapQueue.clear();
        wasEating = false;
    }

    @Override
    public void onDeactivate() {
        NovaChatUtils.sendToggleMsg("AutoConcrete", false);
    }

    private void reset() {
        basePos = null;
        placedDirection = null;
        lastTargetPos = null;
        currentPillarHeight = 1 + 2 * concreteCount.get();
        concretePositions = new class_2338[concreteCount.get()];
        cooldown = 0;
    }

    @EventHandler
    public void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        // 1. Process Queue (Always runs first)
        if (!trapQueue.isEmpty()) {
            FindItemResult queueObsidian = InvUtils
                    .findInHotbar(item -> class_2248.method_9503(item.method_7909()) == class_2246.field_10540);
            Iterator<Map.Entry<class_2338, Integer>> it = trapQueue.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<class_2338, Integer> entry = it.next();
                if (entry.getValue() <= 0) {
                    boolean proceed = true;
                    if (smartPlace.get()) {
                        class_2338 below = entry.getKey().method_10074();
                        class_2680 bs = mc.field_1687.method_8320(below);
                        boolean isPowder = bs.method_26204() instanceof class_2292;
                        boolean isFallingEntity = false;

                        if (!isPowder) {
                            List<class_1297> entities = mc.field_1687.method_8335(null, new class_238(below).method_1009(0, 10, 0));
                            for (class_1297 e : entities) {
                                if (e instanceof class_1540) {
                                    isFallingEntity = true;
                                    break;
                                }
                            }
                        }
                        if (!isPowder && !isFallingEntity)
                            proceed = false;
                    }

                    if (proceed) {
                        if (queueObsidian.found()) {
                            placeTrap(entry.getKey(), queueObsidian);
                        }
                    }
                    it.remove();
                } else {
                    entry.setValue(entry.getValue() - 1);
                }
            }
        }

        if (concretePositions == null || concretePositions.length != concreteCount.get()) {
            concretePositions = new class_2338[concreteCount.get()];
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        if (pauseWhileEating.get() && mc.field_1724 != null) {
            boolean eatingNow = mc.field_1724.method_6115() && isFood(mc.field_1724.method_6030());
            if (eatingNow) {
                wasEating = true;
                return;
            } else if (wasEating) {
                wasEating = false;
            }
        }

        if (TargetUtils.isBadTarget(target, range.get())) {
            target = TargetUtils.getPlayerTarget(range.get(), SortPriority.LowestHealth);
            if (TargetUtils.isBadTarget(target, range.get()))
                return;
            // New target found
        }

        // If we already placed on this target, skip
        if (placedTargets.contains(target.method_5667())) {
            // Optional: check if they moved away from the trap?
            // For now, strict "once per target" as requested.
            return;
        }

        class_2338 targetPos = target.method_24515();

        if (onlyInHole.get() && !isInHole(targetPos))
            return;

        if (smartMode.get() && isObstacle(mc.field_1687.method_8320(targetPos).method_26204()))
            return;

        if (lastTargetPos != null && !lastTargetPos.equals(targetPos)) {
            // reset(); // Don't reset everything, just positions logic
            basePos = null;
            placedDirection = null;
            temporaryPlacedPositions.clear(); // Clear temp positions for new target location
        }
        lastTargetPos = targetPos;

        FindItemResult obsidian = InvUtils
                .findInHotbar(stack -> class_2248.method_9503(stack.method_7909()) == class_2246.field_10540);
        FindItemResult fallingBlock = InvUtils.findInHotbar(stack -> {
            class_2248 block = class_2248.method_9503(stack.method_7909());
            return block == class_2246.field_10102
                    || block == class_2246.field_10534
                    || block == class_2246.field_10255
                    || block == class_2246.field_42728
                    || block == class_2246.field_43227
                    || block instanceof class_2292;
        });

        if (!fallingBlock.found() || (!obsidian.found() && !airPlace.get()))
            return;

        boolean crystalPresent = detectCrystals.get() && isCrystalOnSurround(target);
        currentPillarHeight = 1 + 2 * concreteCount.get();
        if (crystalPresent)
            currentPillarHeight++;

        if (airPlace.get()) {
            for (int i = 0; i < concreteCount.get(); i++) {
                concretePositions[i] = targetPos.method_10086(2 + concreteCount.get() + i);
            }
        } else if (placeSupport.get()) {
            if (placedDirection == null || basePos == null) {
                for (class_2350 dir : class_2350.class_2353.field_11062) {
                    class_2338 side = targetPos.method_10093(dir);
                    if (!mc.field_1687.method_8320(side).method_26215()) {
                        boolean clear = true;
                        for (int i = 0; i < currentPillarHeight; i++) {
                            if (!mc.field_1687.method_8320(side.method_10086(i + 1)).method_45474()) {
                                clear = false;
                                break;
                            }
                        }
                        if (clear) {
                            placedDirection = dir;
                            basePos = side.method_10084();
                            break;
                        }
                    }
                }
            }

            if (basePos == null || placedDirection == null)
                return;

            boolean allPlaced = true;
            for (int i = 0; i < currentPillarHeight; i++) {
                class_2338 pos = basePos.method_10086(i);
                if (!mc.field_1687.method_8320(pos).method_27852(class_2246.field_10540)) {
                    BlockUtils.place(pos, obsidian, rotate.get(), 0);
                    cooldown = pillarDelay.get();
                    allPlaced = false;
                    break;
                }
            }

            if (!allPlaced)
                return;

            for (int i = 0; i < concreteCount.get(); i++) {
                concretePositions[i] = targetPos.method_10086(2 + concreteCount.get() + i);
            }
        }

        for (class_2338 pos : concretePositions) {
            if (pos != null && mc.field_1687.method_8320(pos).method_45474() && !temporaryPlacedPositions.contains(pos)) {
                if (BlockUtils.place(pos, fallingBlock, rotate.get(), 0)) {
                    temporaryPlacedPositions.add(pos);
                }
            }
        }

        // Fish Trap Logic
        if (fishTrap.get() && obsidian.found()) {

            class_2338 fishTrapPos = null;

            // 2. Trigger Queue (Delayed Mode)
            if (!temporaryPlacedPositions.isEmpty()) {
                // Trap = targetPos + count + 1
                fishTrapPos = targetPos.method_10086(concreteCount.get() + 1);

                if (fishTrapPos != null && !trapQueue.containsKey(fishTrapPos)) {
                    // Only add if not already placed/queued
                    class_2248 s = mc.field_1687.method_8320(fishTrapPos).method_26204();
                    if (s != class_2246.field_10540 && s != class_2246.field_9987) {
                        trapQueue.put(fishTrapPos, fishTrapDelay.get());
                    }
                }
            }

            // 3. Scan for existing powder (Backup/Passive Mode)
            // If trap is already queued, skip scan for this pos
            if (fishTrapPos == null || !trapQueue.containsKey(fishTrapPos)) {
                class_2338 baseScan = targetPos;
                boolean foundPowder = false;
                for (int i = 0; i < 5; i++) {
                    if (mc.field_1687.method_8320(baseScan)
                            .method_26204() instanceof net.minecraft.class_2292) {
                        foundPowder = true;
                        while (mc.field_1687.method_8320(baseScan.method_10074())
                                .method_26204() instanceof net.minecraft.class_2292) {
                            baseScan = baseScan.method_10074();
                        }
                        break;
                    }
                    baseScan = baseScan.method_10074();
                }

                if (foundPowder) {
                    class_2338 topPowder = baseScan;
                    while (mc.field_1687.method_8320(topPowder.method_10084())
                            .method_26204() instanceof net.minecraft.class_2292) {
                        topPowder = topPowder.method_10084();
                    }
                    class_2338 scanTrapPos = topPowder.method_10086(2);

                    // If not queued, place immediately (it's existing powder)
                    if (!trapQueue.containsKey(scanTrapPos)) {
                        placeTrap(scanTrapPos, obsidian);
                    }
                }
            }
        }

        // Check if everything is placed to mark as done
        boolean allDone = true;
        // Check concrete (Source blocks must be empty/air implies they fell?)
        // Actually, if we want to confirm they fell, source blocks being AIR is good.
        for (class_2338 pos : concretePositions) {
            if (pos != null && mc.field_1687.method_8320(pos).method_45474() && !temporaryPlacedPositions.contains(pos)) {
                allDone = false;
                break;
            }
        }

        // Check fish trap if enabled
        if (fishTrap.get() && allDone) {
            // Same scan logic for allDone check
            class_2338 baseScan = targetPos;
            boolean foundPowder = false;
            for (int i = 0; i < 5; i++) {
                if (mc.field_1687.method_8320(baseScan).method_26204() instanceof net.minecraft.class_2292) {
                    foundPowder = true;
                    while (mc.field_1687.method_8320(baseScan.method_10074())
                            .method_26204() instanceof net.minecraft.class_2292) {
                        baseScan = baseScan.method_10074();
                    }
                    break;
                }
                baseScan = baseScan.method_10074();
            }

            if (foundPowder) {
                // Find top-most powder block
                class_2338 topPowder = baseScan;
                while (mc.field_1687.method_8320(topPowder.method_10084())
                        .method_26204() instanceof net.minecraft.class_2292) {
                    topPowder = topPowder.method_10084();
                }
                class_2338 fishTrapPos = topPowder.method_10086(2);

                if (mc.field_1687.method_8320(fishTrapPos).method_45474()
                        && !temporaryPlacedPositions.contains(fishTrapPos)) {
                    allDone = false;
                }
            } else {
                // If powder not found yet, we are not done (trap not placed)
                // But if we just placed it, it might still be an entity.
                // Rely on queue check below.
                if (temporaryPlacedPositions.isEmpty()) {
                    // If we haven't placed anything this tick, and no powder found, maybe we are
                    // done?
                    // Keep existing logic: if powder not found, assume done unless queue is active.
                }
            }
        }

        if (!trapQueue.isEmpty())
            allDone = false;

        if (allDone) {
            placedTargets.add(target.method_5667());
        }

        cooldown = concreteDelay.get();

        if (disableOnUse.get())
            toggle();
    }

    private boolean isCrystalOnSurround(class_1657 target) {
        class_2338 pos = target.method_24515();

        // One spatial query covering all four surround boxes, rather than a
        // full entity sweep per direction.
        class_238 search = new class_238(
                pos.method_10263() - 1, pos.method_10264() + 0.5, pos.method_10260() - 1,
                pos.method_10263() + 2, pos.method_10264() + 3.0, pos.method_10260() + 2);
        List<class_1511> crystals = mc.field_1687.method_8390(class_1511.class, search, e -> true);
        if (crystals.isEmpty())
            return false;

        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2338 surround = pos.method_10093(dir);
            for (class_1511 crystal : crystals) {
                if (crystal.method_5829().method_993(
                        surround.method_46558().method_1031(-0.5, 0, -0.5),
                        surround.method_46558().method_1031(0.5, 2.5, 0.5))) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isInHole(class_2338 pos) {
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            if (mc.field_1687.method_8320(pos.method_10093(dir)).method_26215())
                return false;
        }
        return true;
    }

    private boolean isObstacle(class_2248 block) {
        return block instanceof class_2269 || block instanceof class_8810
                || block == class_2246.field_10343 || block == class_2246.field_10589
                || block == class_2246.field_10540 || block == class_2246.field_9987;
    }

    private void placeTrap(class_2338 pos, FindItemResult item) {
        if (pos == null)
            return;

        class_2248 stateBlock = mc.field_1687.method_8320(pos).method_26204();
        if (stateBlock == class_2246.field_10540 || stateBlock == class_2246.field_9987 || temporaryPlacedPositions.contains(pos)) {
            return;
        }
        if (!mc.field_1687.method_8320(pos).method_45474()) {
            return;
        }

        boolean placed = false;
        if (fishTrapAirPlace.get()) {
            if (BlockUtils.place(pos, item, rotate.get(), 50, true, false, true))
                placed = true;
        } else {
            boolean canPlaceNormal = BlockUtils.canPlace(pos);
            if (placeSupport.get() && !canPlaceNormal) {
                for (class_2350 d : class_2350.class_2353.field_11062) {
                    class_2338 adj = pos.method_10093(d);
                    if (mc.field_1687.method_8320(adj).method_45474()
                            && !temporaryPlacedPositions.contains(adj)
                            && BlockUtils.canPlace(adj)) {
                        BlockUtils.place(adj, item, rotate.get(), 50, true, false, true);
                        temporaryPlacedPositions.add(adj);
                        break;
                    }
                }
            }
            if (BlockUtils.canPlace(pos)) {
                if (BlockUtils.place(pos, item, rotate.get(), 50, true, false, true))
                    placed = true;
            }
        }
        if (placed) {
            temporaryPlacedPositions.add(pos);
        }
    }

    private boolean isFood(class_1799 stack) {
        return stack != null && !stack.method_7960() && stack.method_58694(class_9334.field_50075) != null;
    }

    @Override
    public String getInfoString() {
        return target != null ? (airPlace.get() ? "AirPlace - " : "Pillar - ") + EntityUtils.getName(target) : null;
    }
}
